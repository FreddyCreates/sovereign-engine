#!/usr/bin/env python3
from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path


class LinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []
        self.scripts: list[str] = []
        self.styles: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "a" and values.get("href"):
            self.links.append(values["href"] or "")
        if tag == "script" and values.get("src"):
            self.scripts.append(values["src"] or "")
        if tag == "link" and values.get("href"):
            self.styles.append(values["href"] or "")


def assert_exists(base: Path, target: str) -> None:
    if target.startswith(("http://", "https://", "#", "mailto:")):
        return
    path = (base / target).resolve()
    if not path.exists():
        raise SystemExit(f"Missing local target: {target} from {base}")


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    pages = [root / "web" / "index.html", root / "web" / "solver.html", root / "web" / "vault.html"]
    for page in pages:
        parser = LinkParser()
        parser.feed(page.read_text(encoding="utf-8"))
        for target in parser.links + parser.scripts + parser.styles:
            assert_exists(page.parent, target)
    print("link-check-ok")


if __name__ == "__main__":
    main()
