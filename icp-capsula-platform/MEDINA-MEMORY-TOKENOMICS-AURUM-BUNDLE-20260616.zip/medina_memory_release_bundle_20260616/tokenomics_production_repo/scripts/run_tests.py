#!/usr/bin/env python3
from __future__ import annotations

import tempfile
from pathlib import Path

from tokenomics_engine.formulas import allocate_budget, compression_fidelity, crpt, net_score, salience_score
from tokenomics_engine.ledger import JsonlLedger
from tokenomics_engine.models import SalienceVector, ScoreVector, TokenomicsRecord


def test_formulas() -> None:
    scores = ScoreVector(4, 4, 3, 2, 2, 4, 1)
    assert net_score(scores) == 18
    assert crpt(18, 900) == 0.02
    assert salience_score(SalienceVector(4, 5, 5, 3, 4, 1)) == 20
    budgets = allocate_budget(1000, [10, 20, 30])
    assert sum(budgets) == 1000
    assert budgets[2] > budgets[0]
    assert compression_fidelity(5, 4, 4, 1000) == 0.013


def test_ledger() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        ledger = JsonlLedger(Path(tmp) / "ledger.jsonl")
        record = TokenomicsRecord(
            task_id="T-1",
            system_label="tokenomic",
            prompt_tokens=100,
            output_tokens=200,
            scores=ScoreVector(4, 4, 4, 3, 3, 5, 1),
        )
        payload = ledger.append(record)
        assert payload["net_score"] == 22
        assert len(ledger.read_all()) == 1
        assert ledger.summary()["count"] == 1


def main() -> None:
    test_formulas()
    test_ledger()
    print("stdlib-tests-ok")


if __name__ == "__main__":
    main()
