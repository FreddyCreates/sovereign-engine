# Tokenomics Production Repo

Status: production-grade local implementation package / not hosted production deployment.

This repo implements Tokenomics as a real local software surface:

- Python engine for formulas, CRPT scoring, salience, budget allocation, compression fidelity, ledgers, and hash manifests.
- CLI for scoring outputs and appending solver ledger records.
- JSON schemas and seed ledgers.
- Three-page local HTML vault:
  - `web/index.html`
  - `web/solver.html`
  - `web/vault.html`
- Proof and release ledgers.
- Local hash/notary-prep path.

## Install

```bash
python -m pip install -e .
```

## Test

```bash
PYTHONPATH=src python scripts/run_tests.py
python scripts/check_links.py
```

## Score An Output

```bash
tokenomics score --prompt-tokens 500 --output-tokens 900 --dq 4 --act 4 --risk 4 --reuse 5 --learn 3 --accuracy 4 --waste 1
```

## Append Solver Ledger Record

```bash
tokenomics append --ledger data/ledgers/solver_ledger.jsonl --task-id TOK-001 --system-label tokenomic --prompt-tokens 500 --output-tokens 900 --dq 4 --act 4 --risk 4 --reuse 5 --learn 3 --accuracy 4 --waste 1 --rationale "Created reusable artifact with preserved risk."
```

## Open Local Vault

Open directly:

```text
web/index.html
```

Or serve locally:

```bash
python -m http.server 8765
```

Then open:

```text
http://localhost:8765/web/index.html
```

## Formula Stack

```text
TV(t) = w_d D_t + w_a A_t + w_r R_t + w_c C_t + w_m M_t - w_n N_t
NetScore = DQ + ACT + RISK + REUSE + LEARN + ACCURACY - WASTE
CRPT = NetScore / (PromptTokens + OutputTokens)
S_i = alpha U_i + beta R_i + gamma M_i + delta T_i + epsilon X_i - zeta K_i
B_i = B_total * S_i / sum(S)
CEF = (InformationRetained + ActionClarity + RiskPreserved) / OutputTokens
```

## Truth Boundary

This repo is real local code and a real local vault surface. It is not a claim that a hosted production service, legal filing, external notarization, or benchmark superiority already exists.
