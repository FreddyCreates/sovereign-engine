function q(selector) {
  return document.querySelector(selector);
}

function renderMetrics() {
  const records = window.TOKENOMICS_DATA.solverRecords;
  const count = records.length;
  const avgCrpt = count ? records.reduce((sum, row) => sum + row.crpt, 0) / count : 0;
  const avgScore = count ? records.reduce((sum, row) => sum + row.net_score, 0) / count : 0;
  const target = q("[data-metrics]");
  if (!target) return;
  target.innerHTML = `
    <div class="metric"><b>${count}</b><span>solver records</span></div>
    <div class="metric"><b>${avgScore.toFixed(2)}</b><span>avg net score</span></div>
    <div class="metric"><b>${avgCrpt.toFixed(5)}</b><span>avg CRPT</span></div>
  `;
}

function renderFormulaTable() {
  const target = q("[data-formulas]");
  if (!target) return;
  target.innerHTML = window.TOKENOMICS_DATA.formulas.map(([name, formula]) => `
    <tr><td>${name}</td><td><div class="formula">${formula}</div></td></tr>
  `).join("");
}

function renderSolverRows() {
  const target = q("[data-solver-rows]");
  if (!target) return;
  target.innerHTML = window.TOKENOMICS_DATA.solverRecords.map((row) => `
    <tr>
      <td>${row.task_id}</td>
      <td><span class="tag">${row.system_label}</span></td>
      <td>${row.total_tokens}</td>
      <td>${row.net_score}</td>
      <td>${row.crpt.toFixed(5)}</td>
      <td>${row.rationale}</td>
    </tr>
  `).join("");
}

function renderVault() {
  const proof = q("[data-proof]");
  if (proof) {
    proof.innerHTML = window.TOKENOMICS_DATA.proofRecords.map((row) => `
      <tr>
        <td>${row.proof_id}</td>
        <td>${row.claim}</td>
        <td>${row.evidence}</td>
        <td><span class="tag">${row.status}</span></td>
      </tr>
    `).join("");
  }

  const release = q("[data-release]");
  if (release) {
    const boundary = window.TOKENOMICS_DATA.releaseBoundary;
    release.innerHTML = `
      <section class="panel"><h2>Public Safe</h2><ul>${boundary.public_safe.map((x) => `<li>${x}</li>`).join("")}</ul></section>
      <section class="panel"><h2>Internal Controlled</h2><ul>${boundary.internal_controlled.map((x) => `<li>${x}</li>`).join("")}</ul></section>
      <section class="panel"><h2>Blocked Claims</h2><ul>${boundary.blocked_claims.map((x) => `<li>${x}</li>`).join("")}</ul></section>
    `;
  }
}

renderMetrics();
renderFormulaTable();
renderSolverRows();
renderVault();
