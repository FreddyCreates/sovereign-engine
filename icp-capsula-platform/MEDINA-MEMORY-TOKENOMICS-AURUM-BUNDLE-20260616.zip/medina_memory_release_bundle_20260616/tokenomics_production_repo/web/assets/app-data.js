window.TOKENOMICS_DATA = {
  solverRecords: [
    {
      record_id: "tokrec_seed_foundation",
      task_id: "TOK-SEED-001",
      system_label: "tokenomic",
      total_tokens: 1180,
      net_score: 24,
      crpt: 0.020338983050847456,
      release_boundary: "internal_research",
      rationale: "Seed record for full Tokenomics repo: high reuse because it creates formulas, workflows, and callable artifacts."
    }
  ],
  proofRecords: [
    {
      proof_id: "PROOF-001",
      claim: "Tokenomics engine formulas are implemented as local Python functions.",
      evidence: "src/tokenomics_engine/formulas.py",
      status: "implemented_local"
    },
    {
      proof_id: "PROOF-002",
      claim: "Solver ledger can append and summarize JSONL records.",
      evidence: "src/tokenomics_engine/ledger.py and tests/test_ledger.py",
      status: "implemented_local"
    },
    {
      proof_id: "PROOF-003",
      claim: "Local vault pages exist and link together.",
      evidence: "web/index.html, web/solver.html, web/vault.html",
      status: "implemented_local"
    }
  ],
  releaseBoundary: {
    public_safe: [
      "Tokenomics as proposed cognitive return per token framework",
      "CRPT as candidate metric",
      "local vault as demonstrator UI"
    ],
    internal_controlled: [
      "operator ledger records",
      "benchmark data before anonymization",
      "runtime-control deployment decisions"
    ],
    blocked_claims: [
      "production hosted service is deployed",
      "benchmark superiority is verified",
      "legal filing or chain notarization occurred"
    ]
  },
  formulas: [
    ["NetScore", "DQ + ACT + RISK + REUSE + LEARN + ACCURACY - WASTE"],
    ["CRPT", "NetScore / (PromptTokens + OutputTokens)"],
    ["Salience", "alpha U + beta R + gamma M + delta T + epsilon X - zeta K"],
    ["Compression Fidelity", "(InformationRetained + ActionClarity + RiskPreserved) / OutputTokens"]
  ]
};
