from __future__ import annotations

import argparse
import json
from pathlib import Path

from .formulas import allocate_budget, compression_fidelity, crpt, net_score, salience_score
from .hash_manifest import write_manifest
from .ledger import JsonlLedger
from .models import SalienceVector, ScoreVector, TokenomicsRecord


def score_command(args: argparse.Namespace) -> None:
    scores = ScoreVector(args.dq, args.act, args.risk, args.reuse, args.learn, args.accuracy, args.waste)
    net = net_score(scores)
    total_tokens = args.prompt_tokens + args.output_tokens
    print(json.dumps({"net_score": net, "total_tokens": total_tokens, "crpt": crpt(net, total_tokens)}, indent=2))


def append_command(args: argparse.Namespace) -> None:
    scores = ScoreVector(args.dq, args.act, args.risk, args.reuse, args.learn, args.accuracy, args.waste)
    record = TokenomicsRecord(
        task_id=args.task_id,
        system_label=args.system_label,
        prompt_tokens=args.prompt_tokens,
        output_tokens=args.output_tokens,
        scores=scores,
        rationale=args.rationale,
        reviewer=args.reviewer,
        release_boundary=args.release_boundary,
    )
    payload = JsonlLedger(args.ledger).append(record)
    print(json.dumps(payload, indent=2))


def salience_command(args: argparse.Namespace) -> None:
    vector = SalienceVector(args.urgency, args.risk, args.mission, args.time, args.novelty, args.known)
    value = salience_score(vector)
    print(json.dumps({"salience_score": value}, indent=2))


def budget_command(args: argparse.Namespace) -> None:
    values = [float(item) for item in args.salience.split(",")]
    print(json.dumps({"budgets": allocate_budget(args.total_budget, values)}, indent=2))


def compression_command(args: argparse.Namespace) -> None:
    print(
        json.dumps(
            {
                "compression_fidelity": compression_fidelity(
                    args.information_retained,
                    args.action_clarity,
                    args.risk_preserved,
                    args.output_tokens,
                )
            },
            indent=2,
        )
    )


def manifest_command(args: argparse.Namespace) -> None:
    manifest = write_manifest(args.root, args.output)
    print(json.dumps({"output": args.output, "merkle_root": manifest["merkle_root"]}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(prog="tokenomics")
    sub = parser.add_subparsers(required=True)

    score = sub.add_parser("score", help="Compute net score and CRPT.")
    score.add_argument("--prompt-tokens", type=int, required=True)
    score.add_argument("--output-tokens", type=int, required=True)
    for name in ["dq", "act", "risk", "reuse", "learn", "accuracy", "waste"]:
        score.add_argument(f"--{name}", type=float, required=True)
    score.set_defaults(func=score_command)

    append = sub.add_parser("append", help="Append a solver record to a JSONL ledger.")
    append.add_argument("--ledger", default="data/ledgers/solver_ledger.jsonl")
    append.add_argument("--task-id", required=True)
    append.add_argument("--system-label", required=True)
    append.add_argument("--prompt-tokens", type=int, required=True)
    append.add_argument("--output-tokens", type=int, required=True)
    append.add_argument("--rationale", default="")
    append.add_argument("--reviewer", default="operator")
    append.add_argument("--release-boundary", default="internal_research")
    for name in ["dq", "act", "risk", "reuse", "learn", "accuracy", "waste"]:
        append.add_argument(f"--{name}", type=float, required=True)
    append.set_defaults(func=append_command)

    salience = sub.add_parser("salience", help="Compute a salience score.")
    salience.add_argument("--urgency", type=float, required=True)
    salience.add_argument("--risk", type=float, required=True)
    salience.add_argument("--mission", type=float, required=True)
    salience.add_argument("--time", type=float, required=True)
    salience.add_argument("--novelty", type=float, required=True)
    salience.add_argument("--known", type=float, required=True)
    salience.set_defaults(func=salience_command)

    budget = sub.add_parser("budget", help="Allocate token budget from comma-separated salience scores.")
    budget.add_argument("--total-budget", type=int, required=True)
    budget.add_argument("--salience", required=True)
    budget.set_defaults(func=budget_command)

    comp = sub.add_parser("compression", help="Compute compression fidelity.")
    comp.add_argument("--information-retained", type=float, required=True)
    comp.add_argument("--action-clarity", type=float, required=True)
    comp.add_argument("--risk-preserved", type=float, required=True)
    comp.add_argument("--output-tokens", type=int, required=True)
    comp.set_defaults(func=compression_command)

    manifest = sub.add_parser("manifest", help="Build local SHA-256 manifest.")
    manifest.add_argument("--root", default=".")
    manifest.add_argument("--output", default="manifests/hash_manifest.json")
    manifest.set_defaults(func=manifest_command)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
