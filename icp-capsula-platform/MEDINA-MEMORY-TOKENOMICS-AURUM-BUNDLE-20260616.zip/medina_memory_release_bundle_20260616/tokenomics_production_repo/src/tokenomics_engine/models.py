from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(frozen=True)
class ScoreVector:
    decision_quality: float
    actionability: float
    risk_control: float
    reuse_value: float
    learning_gain: float
    accuracy: float
    waste: float

    def validate(self) -> None:
        for name, value in asdict(self).items():
            if not 0 <= value <= 5:
                raise ValueError(f"{name} must be between 0 and 5; got {value}")


@dataclass(frozen=True)
class SalienceVector:
    urgency: float
    risk: float
    mission_relevance: float
    time_sensitivity: float
    novelty: float
    known_context: float

    def validate(self) -> None:
        for name, value in asdict(self).items():
            if not 0 <= value <= 5:
                raise ValueError(f"{name} must be between 0 and 5; got {value}")


@dataclass
class TokenomicsRecord:
    task_id: str
    system_label: str
    prompt_tokens: int
    output_tokens: int
    scores: ScoreVector
    rationale: str = ""
    reviewer: str = "operator"
    release_boundary: str = "internal_research"
    record_id: str = field(default_factory=lambda: f"tokrec_{uuid4().hex[:12]}")
    created_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        from .formulas import crpt, net_score

        total_tokens = self.prompt_tokens + self.output_tokens
        net = net_score(self.scores)
        return {
            "record_id": self.record_id,
            "created_at": self.created_at,
            "task_id": self.task_id,
            "system_label": self.system_label,
            "prompt_tokens": self.prompt_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": total_tokens,
            "scores": asdict(self.scores),
            "net_score": net,
            "crpt": crpt(net, total_tokens),
            "rationale": self.rationale,
            "reviewer": self.reviewer,
            "release_boundary": self.release_boundary,
        }
