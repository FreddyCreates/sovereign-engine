from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_manifest(root: str | Path, exclude: Iterable[str] = ()) -> dict:
    root_path = Path(root)
    excluded = {Path(item) for item in exclude}
    files = []
    for path in sorted(root_path.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root_path)
        if rel in excluded:
            continue
        files.append(
            {
                "path": str(rel),
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    merkle_root = hashlib.sha256("".join(item["sha256"] for item in files).encode()).hexdigest()
    return {
        "manifest_schema": "medina.tokenomics.hash_manifest.v1",
        "algorithm": "SHA-256",
        "files": files,
        "excluded_self_referential_files": [str(item) for item in sorted(excluded)],
        "merkle_root": merkle_root,
        "signature_status": "local_hash_only",
    }


def write_manifest(root: str | Path, output: str | Path) -> dict:
    output_path = Path(output)
    rel_output = output_path.relative_to(Path(root)) if output_path.is_relative_to(Path(root)) else output_path
    manifest = build_manifest(root, exclude=[str(rel_output)])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest
