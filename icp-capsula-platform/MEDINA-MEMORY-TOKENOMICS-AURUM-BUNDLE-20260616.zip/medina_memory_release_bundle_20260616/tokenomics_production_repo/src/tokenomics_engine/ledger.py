from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import TokenomicsRecord


class JsonlLedger:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: TokenomicsRecord) -> dict[str, Any]:
        payload = record.to_dict()
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")
        return payload

    def read_all(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        rows: list[dict[str, Any]] = []
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
        return rows

    def summary(self) -> dict[str, Any]:
        rows = self.read_all()
        if not rows:
            return {"count": 0, "average_crpt": 0, "average_net_score": 0}
        return {
            "count": len(rows),
            "average_crpt": sum(row["crpt"] for row in rows) / len(rows),
            "average_net_score": sum(row["net_score"] for row in rows) / len(rows),
        }
