from __future__ import annotations

from .models import SalienceVector, ScoreVector


def net_score(scores: ScoreVector) -> float:
    scores.validate()
    return (
        scores.decision_quality
        + scores.actionability
        + scores.risk_control
        + scores.reuse_value
        + scores.learning_gain
        + scores.accuracy
        - scores.waste
    )


def crpt(net: float, total_tokens: int | float) -> float:
    if total_tokens <= 0:
        raise ValueError("total_tokens must be positive")
    return net / total_tokens


def salience_score(
    vector: SalienceVector,
    *,
    alpha: float = 1.0,
    beta: float = 1.0,
    gamma: float = 1.0,
    delta: float = 1.0,
    epsilon: float = 1.0,
    zeta: float = 1.0,
) -> float:
    vector.validate()
    return (
        alpha * vector.urgency
        + beta * vector.risk
        + gamma * vector.mission_relevance
        + delta * vector.time_sensitivity
        + epsilon * vector.novelty
        - zeta * vector.known_context
    )


def allocate_budget(total_budget: int, salience_values: list[float]) -> list[int]:
    if total_budget <= 0:
        raise ValueError("total_budget must be positive")
    positive = [max(0.0, value) for value in salience_values]
    total_salience = sum(positive)
    if total_salience == 0:
        even = total_budget // len(positive)
        budgets = [even for _ in positive]
    else:
        budgets = [int(round(total_budget * value / total_salience)) for value in positive]
    drift = total_budget - sum(budgets)
    if budgets:
        budgets[-1] += drift
    return budgets


def compression_fidelity(
    information_retained: float,
    action_clarity: float,
    risk_preserved: float,
    output_tokens: int | float,
) -> float:
    for name, value in {
        "information_retained": information_retained,
        "action_clarity": action_clarity,
        "risk_preserved": risk_preserved,
    }.items():
        if not 0 <= value <= 5:
            raise ValueError(f"{name} must be between 0 and 5")
    if output_tokens <= 0:
        raise ValueError("output_tokens must be positive")
    return (information_retained + action_clarity + risk_preserved) / output_tokens
