# Production Runbook

## Local Install

```bash
python -m pip install -e .
```

## Run Tests

```bash
PYTHONPATH=src python scripts/run_tests.py
python scripts/check_links.py
```

## Score An Output

```bash
tokenomics score --prompt-tokens 500 --output-tokens 900 --dq 4 --act 4 --risk 4 --reuse 5 --learn 3 --accuracy 4 --waste 1
```

## Append A Solver Ledger Record

```bash
tokenomics append --ledger data/ledgers/solver_ledger.jsonl --task-id TOK-001 --system-label tokenomic --prompt-tokens 500 --output-tokens 900 --dq 4 --act 4 --risk 4 --reuse 5 --learn 3 --accuracy 4 --waste 1 --rationale "Created reusable artifact with preserved risk."
```

## Open Local Vault

Open `web/index.html` directly in a browser, or run:

```bash
python -m http.server 8765
```

Then visit:

```text
http://localhost:8765/web/index.html
```

## Build Local Hash Manifest

```bash
tokenomics manifest --root . --output manifests/hash_manifest.json
```

## Deployment Boundary

This repo is a real local implementation and demonstrator. Production hosting still requires authentication, persistent storage, backup policy, deployment target, monitoring, and operator approval.
