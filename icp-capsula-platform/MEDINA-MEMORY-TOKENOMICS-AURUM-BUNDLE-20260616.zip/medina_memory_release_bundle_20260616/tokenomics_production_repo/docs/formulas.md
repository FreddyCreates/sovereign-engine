# Tokenomics Formula Stack

## Token Value

```text
TV(t) = w_d D_t + w_a A_t + w_r R_t + w_c C_t + w_m M_t - w_n N_t
```

## Operational Score

```text
NetScore = DQ + ACT + RISK + REUSE + LEARN + ACCURACY - WASTE
```

## Cognitive Return Per Token

```text
CRPT = NetScore / (PromptTokens + OutputTokens)
```

## Salience

```text
S_i = alpha U_i + beta R_i + gamma M_i + delta T_i + epsilon X_i - zeta K_i
```

## Budget Allocation

```text
B_i = B_total * S_i / sum(S)
```

## Compression Fidelity

```text
CEF = (InformationRetained + ActionClarity + RiskPreserved) / OutputTokens
```

## Truth Boundary

These formulas are implemented locally in `src/tokenomics_engine`. They are a production-grade local implementation surface, not proof of external benchmark superiority or hosted deployment.
