from tokenomics_engine.formulas import allocate_budget, compression_fidelity, crpt, net_score, salience_score
from tokenomics_engine.models import SalienceVector, ScoreVector


def test_net_score_and_crpt():
    scores = ScoreVector(4, 4, 3, 2, 2, 4, 1)
    assert net_score(scores) == 18
    assert crpt(18, 900) == 0.02


def test_salience_score():
    vector = SalienceVector(urgency=4, risk=5, mission_relevance=5, time_sensitivity=3, novelty=4, known_context=1)
    assert salience_score(vector) == 20


def test_allocate_budget_preserves_total():
    budgets = allocate_budget(1000, [10, 20, 30])
    assert sum(budgets) == 1000
    assert budgets[2] > budgets[0]


def test_compression_fidelity():
    assert compression_fidelity(5, 4, 4, 1000) == 0.013
