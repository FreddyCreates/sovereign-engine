from tokenomics_engine.ledger import JsonlLedger
from tokenomics_engine.models import ScoreVector, TokenomicsRecord


def test_ledger_append_and_summary(tmp_path):
    ledger = JsonlLedger(tmp_path / "ledger.jsonl")
    record = TokenomicsRecord(
        task_id="T-1",
        system_label="tokenomic",
        prompt_tokens=100,
        output_tokens=200,
        scores=ScoreVector(4, 4, 4, 3, 3, 5, 1),
    )
    payload = ledger.append(record)
    assert payload["net_score"] == 22
    rows = ledger.read_all()
    assert len(rows) == 1
    assert ledger.summary()["count"] == 1
