# AURUM ICP Forge Console v0 Spec

Status: `WORKING_PAPER / LOCAL_IMPLEMENTATION_READY`

## Objective

AURUM ICP Forge Console turns doctrine packets, app ideas, repos, and scaffolds into a controlled Internet Computer project lifecycle. The first vertical slice is:

```text
Local ICP Project -> Validated icp.yaml -> Local Command Plan -> Canister Discovery -> Bindings Record -> Proof Packet
```

## Operator Layers

1. Project Intake
2. ICP Environment Console
3. Build / Deploy / Sync Runtime
4. Proof + Promotion Registry

## First API Surface

- `POST /projects`
- `POST /projects/{id}/recipe`
- `POST /projects/{id}/build`
- `POST /projects/{id}/deploy-local`
- `GET /projects/{id}/canisters`
- `GET /deploy-runs/{id}/logs`
- `GET /deploy-runs/{id}/proof`

## Mainnet Boundary

Mainnet deploy is blocked until:

- staging deploy proof exists
- identity alias is selected
- cycles preflight passes
- config diff is approved
- snapshot recommendation is acknowledged
- promotion gate is approved

## Proof Record

A deployment proof record must include:

- repo commit
- `icp.yaml` config hash
- identity alias
- environment/network
- canister IDs
- generated bindings
- command trace
- logs/check status
- snapshot/migration risk handling

## Truth Boundary

This v0 surface contains working local code and contracts. It does not execute live `icp-cli`, deploy to mainnet, hold production identities, or spend cycles.
