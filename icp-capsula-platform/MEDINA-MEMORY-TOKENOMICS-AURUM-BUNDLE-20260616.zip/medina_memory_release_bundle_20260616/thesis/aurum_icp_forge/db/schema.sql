create table icp_projects (
  id text primary key,
  repo_url text,
  root_path text not null,
  icp_yaml_path text not null,
  active_environment text not null check (active_environment in ('dev', 'staging', 'production')),
  created_at timestamptz not null default now()
);

create table icp_environments (
  project_id text not null references icp_projects(id),
  name text not null check (name in ('dev', 'staging', 'production')),
  network text not null,
  identity_alias text not null,
  subnet_target text,
  cycles_budget text,
  primary key (project_id, name)
);

create table canister_records (
  id bigserial primary key,
  project_id text not null references icp_projects(id),
  name text not null,
  canister_id text,
  type text not null,
  subnet text,
  settings_hash text,
  unique (project_id, name)
);

create table deploy_runs (
  id text primary key,
  project_id text not null references icp_projects(id),
  environment text not null,
  command text not null,
  status text not null check (status in ('queued', 'running', 'passed', 'failed', 'blocked')),
  commit_sha text,
  started_at timestamptz not null,
  completed_at timestamptz
);

create table deployment_proof_records (
  id text primary key,
  deploy_run_id text not null references deploy_runs(id),
  config_hash text not null,
  proof_hash text not null,
  command_trace jsonb not null,
  generated_bindings jsonb not null,
  canisters jsonb not null,
  truth_boundary text not null,
  created_at timestamptz not null default now()
);

create table promotion_gates (
  deploy_run_id text primary key references deploy_runs(id),
  required_checks jsonb not null,
  approved_by text,
  proof_record_id text references deployment_proof_records(id)
);
