export type EnvironmentName = "dev" | "staging" | "production";

export type IcpProject = {
  id: string;
  repoUrl?: string;
  rootPath: string;
  icpYamlPath: string;
  activeEnvironment: EnvironmentName;
};

export type IcpEnvironment = {
  name: EnvironmentName;
  network: "local" | "mainnet" | string;
  identityAlias: string;
  subnetTarget?: string;
  cyclesBudget?: string;
};

export type CanisterRecord = {
  name: string;
  canisterId?: string;
  type: "motoko" | "rust" | "assets" | "custom" | string;
  subnet?: string;
  settingsHash?: string;
};

export type DeployRun = {
  id: string;
  projectId: string;
  environment: EnvironmentName;
  command: "build" | "deploy" | "sync" | "snapshot" | "migrate" | "bindings";
  status: "queued" | "running" | "passed" | "failed" | "blocked";
  commitSha?: string;
  startedAt: string;
  completedAt?: string;
};

export type PromotionGate = {
  deployRunId: string;
  requiredChecks: string[];
  approvedBy?: string;
  proofRecordId?: string;
};

export type DeploymentProofRecord = {
  proofRecordId: string;
  project: IcpProject;
  environment: IcpEnvironment;
  deployRun: DeployRun;
  canisters: CanisterRecord[];
  commandTrace: string[];
  generatedBindings: string[];
  configHash: string;
  proofHash: string;
};
