# AURUM ICP Forge Console v0

Authority state: `WORKING_PAPER / LOCAL_IMPLEMENTATION_READY / MAINNET_BLOCKED`

This surface turns the `icp-cli` product architecture into a working Medina memory artifact with code, schemas, proof ledgers, and a local deployment boundary.

## Product Surface

**AURUM ICP Forge Console** is an operator console and runtime boundary for taking an ICP project from idea or repo scaffold through recipe selection, `icp.yaml` validation, local build/deploy planning, canister discovery, generated bindings capture, deployment proof records, and gated promotion.

## Current Working Slice

Implemented now:

- strict Python model layer for projects, environments, canisters, deploy runs, and promotion gates
- `icp.yaml` JSON/YAML-like validation boundary
- command planner for local ICP lifecycle commands
- mainnet/staging safety gates
- proof record builder
- local hash manifest builder
- no-dependency test runner
- TypeScript contracts
- SQL schema
- OpenAPI route surface
- operator UI wireframe

Not claimed:

- live `icp-cli` execution
- mainnet deployment
- cycles wallet custody
- production identity handling
- chain notarization

## Run Checks

```bash
PYTHONPATH=src python tests/run_tests.py
```

## Boundary

This is now working code and a working paper surface. It is still local-only until a real ICP execution environment, identity policy, cycles preflight, storage backend, and operator approval gate are attached.
