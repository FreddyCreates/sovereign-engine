# AURUM ICP Forge Release Boundary

## Public-Safe

- AURUM ICP Forge Console as operator product concept.
- Local-first ICP project lifecycle wrapper.
- Mainnet deploy gating as safety architecture.
- Proof record requirements.

## Internal-Controlled

- Identity handling policy.
- Cycles wallet operations.
- Production deploy worker.
- Subnet target selection policy.
- Real deployment logs before redaction.

## Blocked

- Claiming live ICP deployment.
- Claiming mainnet readiness.
- Claiming cycles custody.
- Claiming external notarization.

## Current Authority

`WORKING_PAPER / LOCAL_IMPLEMENTATION_READY / MAINNET_BLOCKED`
