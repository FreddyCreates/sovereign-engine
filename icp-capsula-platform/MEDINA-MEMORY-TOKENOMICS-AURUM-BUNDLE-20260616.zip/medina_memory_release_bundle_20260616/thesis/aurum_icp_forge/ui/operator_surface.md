# AURUM ICP Forge Operator UI

## Screens

1. Projects
2. Environment Manager
3. Recipe Studio
4. Deploy Console
5. Canister Registry
6. Promotion Gate
7. Proof Packet

## First Screen

The first screen should be the Projects dashboard, not a marketing page. It should show:

- project name
- linked repo
- active environment
- last deploy status
- proof status
- blocked gates

## Deploy Console Controls

- Build
- Deploy Local
- Generate Bindings
- Snapshot
- Promote To Staging
- Export Proof Packet

Mainnet deploy remains disabled until the Promotion Gate is open.
