# AURUM ICP Forge Console: Working Paper and Local Implementation Surface

Authority state: `WORKING_PAPER / LOCAL_IMPLEMENTATION_READY / MAINNET_BLOCKED`

## Abstract

AURUM ICP Forge Console is a proposed and partially implemented operator surface for Internet Computer project lifecycle management. It treats `icp-cli` as a deployment spine and wraps it with project intake, recipe selection, environment validation, deploy command planning, canister discovery, generated binding capture, proof records, and promotion gates. The first vertical slice is intentionally narrow: take one ICP project through validated local deployment planning and proof packet generation while blocking staging and mainnet promotion unless identity, cycles, subnet, config, snapshot, and approval checks exist.

This paper is now a working paper in the Medina sense: it is paired with executable local code, schemas, tests, and proof records. It does not claim live ICP deployment, mainnet execution, cycles custody, or chain notarization.

## 1. Product Claim

The strongest product surface is:

```text
AURUM ICP Forge Console
```

It is not merely a web console. It is an operator boundary around the Internet Computer deployment lifecycle. Its job is to prevent a project from jumping from idea to mainnet without substrate awareness: repo commit, `icp.yaml`, environment, identity alias, network, cycles budget, canister IDs, bindings, command trace, snapshot posture, and proof record.

## 2. Runtime Interpretation

The system routes through ORIGO, SENSUS, and CORPUS:

- ORIGO: project intake and recipe origin.
- SENSUS: substrate classification before action.
- CORPUS: artifact generation, deployment packet, proof record, and local code.

The active substrate classes are:

- local network
- staging network
- production/mainnet network
- identity alias
- cycles wallet boundary
- canister state
- generated bindings
- promotion gate
- proof record

## 3. Product Architecture

The app exposes four operator layers:

1. Project Intake
2. ICP Environment Console
3. Build / Deploy / Sync Runtime
4. Proof + Promotion Registry

The first usable product flow is:

1. Operator imports or creates an ICP project.
2. App validates or creates `icp.yaml`.
3. Operator selects a recipe.
4. App plans local lifecycle commands.
5. App captures canister IDs, binding names, logs, and config hash.
6. App generates proof record.
7. Staging and mainnet remain locked behind promotion gates.

## 4. Core Contracts

The TypeScript contracts are implemented in `schemas/contracts.ts`. The Python contracts are implemented in `src/aurum_icp/models.py`.

Core objects:

- `IcpProject`
- `IcpEnvironment`
- `CanisterRecord`
- `DeployRun`
- `PromotionGate`
- `DeploymentProofRecord`

## 5. Command Runner Boundary

The current implementation includes a safe command planner, not a raw shell runner. This is deliberate. A production command runner must sandbox execution, capture logs, enforce identity boundaries, and prevent uncontrolled mainnet actions.

The command planner produces `CommandPlan` objects such as:

```text
icp deploy --config icp.yaml --env dev
```

Production deploy requires an open promotion gate. Without it, the code raises a `PermissionError`.

## 6. Database Schema

The Postgres schema in `db/schema.sql` defines:

- projects
- environments
- canisters
- deploy runs
- proof records
- promotion gates

This is enough for the first vertical slice and leaves room for logs, snapshots, object storage references, and identity audit tables.

## 7. API Surface

The OpenAPI file in `api/openapi.json` defines the first routes:

- `POST /projects`
- `POST /projects/{id}/recipe`
- `POST /projects/{id}/build`
- `POST /projects/{id}/deploy-local`
- `GET /projects/{id}/canisters`
- `GET /deploy-runs/{id}/logs`
- `GET /deploy-runs/{id}/proof`

## 8. Proof Signal

A deployment is only certified when the system can prove:

- which repo commit produced it
- which `icp.yaml` configuration was used
- which identity alias deployed it
- which network received it
- which canister IDs were created or updated
- which bindings were generated
- which logs and checks passed
- whether snapshot or migration risk was handled

The local proof builder creates a hash-backed proof record. It is local proof, not chain notarization.

## 9. Test Matrix

Current tests prove:

- valid `icp.yaml`-compatible JSON passes validation
- invalid config is blocked
- local deploy command plan is generated
- production deploy is blocked without promotion gate
- proof record contains config hash and proof hash

Future tests should cover:

- staging identity missing
- cycles preflight missing
- config hash changes on canister setting changes
- snapshot warning before migration
- reproducible recipe output from a clean workspace

## 10. Deployment Posture

Stage 1: local-only command planner and proof packet. Implemented now.

Stage 2: staging deploy worker with explicit identity and cycles preflight. Not yet implemented.

Stage 3: mainnet deploy gate with config diff, approval, and snapshot recommendation. Not yet implemented.

Stage 4: subnet targeting and migration support. Not yet implemented.

Stage 5: sync plugin studio and dfx migration assistant. Not yet implemented.

## 11. Conclusion

AURUM ICP Forge Console is now a working paper plus local implementation surface. The product is no longer only conceptual: code exists, tests exist, schemas exist, proof records can be built, and mainnet is actively blocked until promotion proof exists.
