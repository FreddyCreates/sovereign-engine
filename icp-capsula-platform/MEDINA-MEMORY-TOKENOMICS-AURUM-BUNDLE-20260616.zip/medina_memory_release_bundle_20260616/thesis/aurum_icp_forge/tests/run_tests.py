#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

from aurum_icp.config import assert_valid_icp_config, load_icp_config, validate_icp_config
from aurum_icp.models import CanisterRecord, DeployRun, IcpEnvironment, IcpProject
from aurum_icp.proof import build_proof_record
from aurum_icp.runner import IcpCommandPlanner


def test_config_validation() -> None:
    config = load_icp_config(Path(__file__).parents[1] / "examples" / "icp.example.json")
    assert_valid_icp_config(config)
    invalid = {"project": {}, "environments": {}, "canisters": {}}
    assert validate_icp_config(invalid)


def test_command_planner_blocks_mainnet_without_gate() -> None:
    project = IcpProject(root_path="/tmp/app", icp_yaml_path="icp.yaml")
    env = IcpEnvironment(name="production", network="mainnet", identity_alias="prod")
    planner = IcpCommandPlanner(project, env)
    try:
        planner.deploy_production(promotion_gate_open=False)
    except PermissionError:
        pass
    else:
        raise AssertionError("production deploy should be blocked without promotion gate")


def test_local_deploy_plan() -> None:
    project = IcpProject(root_path="/tmp/app", icp_yaml_path="icp.yaml")
    env = IcpEnvironment(name="dev", network="local", identity_alias="local-dev")
    plan = IcpCommandPlanner(project, env).deploy_local()
    assert plan.shell_preview() == "icp deploy --config icp.yaml --env dev"


def test_proof_record() -> None:
    project = IcpProject(root_path="/tmp/app", icp_yaml_path="icp.yaml")
    env = IcpEnvironment(name="dev", network="local", identity_alias="local-dev")
    run = DeployRun(project_id=project.id, environment="dev", command="deploy", status="passed")
    proof = build_proof_record(
        project=project,
        environment=env,
        deploy_run=run,
        canisters=[CanisterRecord(name="backend", type="motoko", canister_id="aaaaa-aa")],
        command_trace=["icp build", "icp deploy"],
        generated_bindings=["backend.did.js"],
        config={"project": {"name": "demo"}, "environments": {"dev": {"network": "local", "identityAlias": "local-dev"}}, "canisters": {"backend": {"type": "motoko"}}},
    )
    assert proof["proof_hash"]
    assert proof["config_hash"]


def main() -> None:
    test_config_validation()
    test_command_planner_blocks_mainnet_without_gate()
    test_local_deploy_plan()
    test_proof_record()
    print("aurum-tests-ok")


if __name__ == "__main__":
    main()
