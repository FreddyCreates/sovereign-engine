from __future__ import annotations

import hashlib
import json
from pathlib import Path


def build_hash_manifest(root: str | Path, exclude: set[str] | None = None) -> dict:
    root_path = Path(root)
    excluded = {Path(item) for item in (exclude or set())}
    files = []
    for path in sorted(root_path.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root_path)
        if rel in excluded:
            continue
        data = path.read_bytes()
        files.append({"path": str(rel), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
    merkle_root = hashlib.sha256("".join(item["sha256"] for item in files).encode()).hexdigest()
    return {
        "manifest_schema": "medina.aurum_icp.hash_manifest.v1",
        "algorithm": "SHA-256",
        "files": files,
        "merkle_root": merkle_root,
        "signature_status": "local_hash_only",
    }
