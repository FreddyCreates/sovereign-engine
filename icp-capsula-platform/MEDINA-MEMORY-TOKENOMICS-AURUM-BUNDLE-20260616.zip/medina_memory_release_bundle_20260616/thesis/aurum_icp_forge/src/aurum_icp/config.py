from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REQUIRED_TOP_LEVEL = {"project", "environments", "canisters"}
REQUIRED_ENV_FIELDS = {"network", "identityAlias"}
REQUIRED_CANISTER_FIELDS = {"type"}


def load_icp_config(path: str | Path) -> dict[str, Any]:
    """Load strict JSON-compatible icp.yaml content.

    The first implementation accepts JSON syntax because the Python standard
    library has no YAML parser. Production deployment can swap in a YAML parser
    behind this stable validation contract.
    """

    raw = Path(path).read_text(encoding="utf-8")
    return json.loads(raw)


def validate_icp_config(config: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    missing = REQUIRED_TOP_LEVEL - set(config)
    for key in sorted(missing):
        errors.append(f"missing top-level field: {key}")

    environments = config.get("environments", {})
    if not isinstance(environments, dict) or not environments:
        errors.append("environments must be a non-empty object")
    else:
        for name, env in environments.items():
            if not isinstance(env, dict):
                errors.append(f"environment {name} must be an object")
                continue
            for field in sorted(REQUIRED_ENV_FIELDS - set(env)):
                errors.append(f"environment {name} missing field: {field}")

    canisters = config.get("canisters", {})
    if not isinstance(canisters, dict) or not canisters:
        errors.append("canisters must be a non-empty object")
    else:
        for name, canister in canisters.items():
            if not isinstance(canister, dict):
                errors.append(f"canister {name} must be an object")
                continue
            for field in sorted(REQUIRED_CANISTER_FIELDS - set(canister)):
                errors.append(f"canister {name} missing field: {field}")
    return errors


def assert_valid_icp_config(config: dict[str, Any]) -> None:
    errors = validate_icp_config(config)
    if errors:
        raise ValueError("; ".join(errors))
