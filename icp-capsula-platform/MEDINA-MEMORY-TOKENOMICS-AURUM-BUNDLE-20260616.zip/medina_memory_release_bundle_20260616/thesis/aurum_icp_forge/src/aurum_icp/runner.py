from __future__ import annotations

import shlex
from dataclasses import dataclass

from .models import IcpEnvironment, IcpProject


@dataclass(frozen=True)
class CommandPlan:
    command: str
    args: list[str]
    environment: str
    dry_run: bool = True

    def shell_preview(self) -> str:
        return " ".join(shlex.quote(part) for part in [self.command, *self.args])


class IcpCommandPlanner:
    """Safe command planner for the `icp-cli` lifecycle.

    This planner builds command plans and enforces environment gates. It does
    not execute shell commands. A production worker can consume CommandPlan
    objects and execute them inside a sandbox with log capture.
    """

    def __init__(self, project: IcpProject, environment: IcpEnvironment) -> None:
        self.project = project
        self.environment = environment

    def _base(self, action: str) -> CommandPlan:
        return CommandPlan(
            command="icp",
            args=[action, "--config", self.project.icp_yaml_path, "--env", self.environment.name],
            environment=self.environment.name,
        )

    def install(self) -> CommandPlan:
        return self._base("install")

    def build(self) -> CommandPlan:
        return self._base("build")

    def deploy_local(self) -> CommandPlan:
        if self.environment.network != "local":
            raise ValueError("deploy_local requires a local network environment")
        return self._base("deploy")

    def deploy_staging(self) -> CommandPlan:
        if self.environment.name != "staging":
            raise ValueError("deploy_staging requires staging environment")
        self.environment.validate_for_deploy()
        return self._base("deploy")

    def deploy_production(self, promotion_gate_open: bool) -> CommandPlan:
        if self.environment.name != "production":
            raise ValueError("deploy_production requires production environment")
        if not promotion_gate_open:
            raise PermissionError("production deploy blocked until promotion gate passes")
        self.environment.validate_for_deploy()
        return self._base("deploy")

    def snapshot(self) -> CommandPlan:
        return self._base("snapshot")

    def bindings(self) -> CommandPlan:
        return self._base("generate-bindings")
