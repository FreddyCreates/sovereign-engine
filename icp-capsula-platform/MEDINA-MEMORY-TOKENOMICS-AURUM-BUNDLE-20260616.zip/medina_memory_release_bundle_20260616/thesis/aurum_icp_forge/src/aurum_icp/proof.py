from __future__ import annotations

import hashlib
import json
from pathlib import Path
from uuid import uuid4

from .models import CanisterRecord, DeployRun, IcpEnvironment, IcpProject


def stable_hash(payload: dict) -> str:
    encoded = json.dumps(payload, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def build_proof_record(
    *,
    project: IcpProject,
    environment: IcpEnvironment,
    deploy_run: DeployRun,
    canisters: list[CanisterRecord],
    command_trace: list[str],
    generated_bindings: list[str],
    config: dict,
) -> dict:
    config_hash = stable_hash(config)
    record = {
        "proof_record_id": f"proof_{uuid4().hex[:12]}",
        "project": project.to_dict(),
        "environment": environment.__dict__,
        "deploy_run": deploy_run.to_dict(),
        "canisters": [item.to_dict() for item in canisters],
        "command_trace": command_trace,
        "generated_bindings": generated_bindings,
        "config_hash": config_hash,
        "truth_boundary": "local proof record; not external notarization",
    }
    record["proof_hash"] = stable_hash(record)
    return record


def write_proof_record(path: str | Path, record: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
