from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4


EnvironmentName = Literal["dev", "staging", "production"]
DeployCommand = Literal["build", "deploy", "sync", "snapshot", "migrate", "bindings"]
DeployStatus = Literal["queued", "running", "passed", "failed", "blocked"]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass
class IcpProject:
    root_path: str
    icp_yaml_path: str
    active_environment: EnvironmentName = "dev"
    repo_url: str | None = None
    id: str = field(default_factory=lambda: f"icp_proj_{uuid4().hex[:12]}")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class IcpEnvironment:
    name: EnvironmentName
    network: str
    identity_alias: str
    subnet_target: str | None = None
    cycles_budget: str | None = None

    def validate_for_deploy(self) -> None:
        if self.name in {"staging", "production"} and not self.identity_alias:
            raise ValueError("staging/production deploy requires an identity alias")
        if self.name == "production" and self.network == "local":
            raise ValueError("production environment cannot target local network")


@dataclass
class CanisterRecord:
    name: str
    type: str
    canister_id: str | None = None
    subnet: str | None = None
    settings_hash: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DeployRun:
    project_id: str
    environment: EnvironmentName
    command: DeployCommand
    status: DeployStatus = "queued"
    commit_sha: str | None = None
    started_at: str = field(default_factory=utc_now)
    completed_at: str | None = None
    id: str = field(default_factory=lambda: f"deploy_{uuid4().hex[:12]}")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class PromotionGate:
    deploy_run_id: str
    required_checks: list[str]
    approved_by: str | None = None
    proof_record_id: str | None = None

    def is_open(self) -> bool:
        return self.approved_by is not None and self.proof_record_id is not None

    def to_dict(self) -> dict:
        return asdict(self)
