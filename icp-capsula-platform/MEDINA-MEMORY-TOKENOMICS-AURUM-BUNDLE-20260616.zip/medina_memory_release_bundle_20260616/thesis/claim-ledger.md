# Claim Ledger

## 2026-05-14: Foundation Floor Packet

- `CLAIM-001` `C4`: Foundation Floor as lawful heavy compute under NOVA_ROOT. Status: draft architecture thesis supported only by concept statement.
- `CLAIM-002` `C7`: Canonical memory protection via MEMORY_RUNTIME-mediated writes. Status: internal-only runtime law candidate awaiting stronger proof.
- `CLAIM-003` `C9`: Bounded authority membrane theorem. Status: theorem candidate only; not proven.
- `CLAIM-004` `C3`: Auditability improves under compute/memory split. Status: unsupported hypothesis awaiting experiment.
- `CLAIM-006` `C8`: Queue-and-review deployment bridge. Status: protocol candidate only, not a deployment claim.
- `CLAIM-008` `C6`: Mediation internals, authority enforcement, and memory routing mechanisms. Status: private core material; never public without deliberate review.

## 2026-05-14: Extension Claims

- `CLAIM-009` `C12 framing`: notary-preparation path exists, but only as preparation language. Status: public-safe only when explicitly marked as no-receipt and no-completion.
- `CLAIM-010` `C8`: staged deployment protocol candidate with queue, execution, evidence, review, promotion, and rollback boundaries. Status: internal protocol candidate only; still non-deployed.

## 2026-05-14: Archive Packet Claims

- `CLAIM-011` `C1`: packet tooling exists for validation, rendering, and local hash-manifest generation. Status: implemented inside the packet as code artifacts.
- `CLAIM-012` `C10`: public-safe derivative may describe bounded heavy compute and protected canonical memory without disclosing private core. Status: bounded derivative prepared.
- `CLAIM-013` `C12`: packet is hashed locally with Merkle-root continuity only. Status: HASHED, not notarized.
- `CLAIM-014` `C8`: placeholder token-adapter path exists for internal token-intent intake only. Status: internal protocol-candidate infrastructure; non-settling and non-production.

## 2026-06-14: Tokenomics Full Research Surface Claims

- `CLAIM-TOK-001` `C4/C9`: Tokenomics reframes token use as cognitive budget governance and proposes Cognitive Return Per Token as a measurement target. Status: full internal research paper prepared; theorem/program claim, not empirical proof.
- `CLAIM-TOK-002` `C8/C9`: Token Value, CRPT, salience allocation, compression fidelity, and TokenomicGain form a protocol-candidate model stack. Status: formulas and model schema exist; validation pending.
- `CLAIM-TOK-003` `C8`: Tokenomic benchmark architecture can compare baseline and tokenomic outputs across operational, research, architecture, red-team, and memory tasks. Status: benchmark protocol and seed tasks exist; benchmark results not yet executed.
- `CLAIM-TOK-004` `C1`: callable local scoring utility exists for computing net score and CRPT from supplied rubric values. Status: implemented as `tokenomics_callable_scorer.py`; not a production runtime.
- `CLAIM-TOK-005` `C3`: Tokenomic systems will outperform baseline systems in CRPT on selected high-value task classes. Status: hypothesis only until benchmark records exist.
- `CLAIM-TOK-006` `C6/C5`: exact runtime-control integration and agent-injection substrate are controlled internal materials. Status: internal research; public release requires boundary review.

## 2026-06-16: AURUM ICP Forge Console Claims

- `CLAIM-AURUM-001` `C8/C5`: AURUM ICP Forge Console is a protocol/product candidate for wrapping `icp-cli` lifecycle with project intake, environment validation, local deploy planning, proof packets, and promotion gates. Status: working paper plus local implementation surface.
- `CLAIM-AURUM-002` `C1`: Python model, config validator, command planner, proof builder, and hash helper exist locally. Status: implemented and tested by `aurum-tests-ok`.
- `CLAIM-AURUM-003` `C1`: Production deploy is blocked unless a promotion gate is open. Status: implemented in command planner test; local proof only.
- `CLAIM-AURUM-004` `C8`: SQL schema, OpenAPI routes, TypeScript contracts, and operator UI surface define the first product architecture. Status: generated artifacts; not deployed service.
- `CLAIM-AURUM-005` `C3`: AURUM can become a full ICP deployment product suite. Status: strategic thesis; requires real `icp-cli` worker, identity policy, cycles preflight, storage, and deploy evidence.
- `CLAIM-AURUM-006` `C6`: identity handling, cycles wallet operations, and production deploy worker remain internal-controlled. Status: not public-ready.
