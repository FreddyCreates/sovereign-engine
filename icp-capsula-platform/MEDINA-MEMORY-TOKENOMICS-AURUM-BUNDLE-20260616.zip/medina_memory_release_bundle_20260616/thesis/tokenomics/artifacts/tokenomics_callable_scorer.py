#!/usr/bin/env python3
import argparse, json
parser = argparse.ArgumentParser(description='Compute Tokenomics net score and CRPT.')
parser.add_argument('--tokens', type=float, required=True)
for name in ['dq','act','risk','reuse','learn','accuracy','waste']:
    parser.add_argument('--'+name, type=float, required=True)
args = parser.parse_args()
net = args.dq + args.act + args.risk + args.reuse + args.learn + args.accuracy - args.waste
crpt = net / args.tokens if args.tokens else 0.0
print(json.dumps({'net_score': net, 'crpt': crpt, 'tokens': args.tokens}, indent=2))
