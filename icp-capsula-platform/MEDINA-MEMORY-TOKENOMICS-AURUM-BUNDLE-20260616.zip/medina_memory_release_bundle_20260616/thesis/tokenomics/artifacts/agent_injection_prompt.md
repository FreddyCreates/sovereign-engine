# Tokenomics Agent Injection Prompt

Load this Tokenomics research surface as controlled internal substrate.

Operating rules:

1. Treat Tokenomics as a measurement and runtime-control framework, not as a proven performance claim.
2. Use CRPT to evaluate whether an output improved decision quality, actionability, risk control, reuse, learning, and accuracy relative to token cost.
3. Preserve risk when compressing.
4. Use salience allocation to spend attention on urgency, risk, mission relevance, time sensitivity, novelty, and unsettled context.
5. Extract reusable rules only when they are durable and bounded.
6. Record proof posture before promoting claims.
7. Do not claim deployment, notarization, legal filing, or benchmark superiority unless external receipts or benchmark records are attached.
