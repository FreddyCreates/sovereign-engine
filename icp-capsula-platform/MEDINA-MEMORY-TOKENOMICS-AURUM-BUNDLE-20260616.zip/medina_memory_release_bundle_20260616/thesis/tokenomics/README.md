# Tokenomics Research Surface

This repo surface records the full Tokenomics research expansion from the Phantom protection packet into two complete papers and callable artifacts.

## Full Papers

- `papers/tokenomics_measurement_theory_full.md`
- `papers/tokenomic_benchmark_runtime_architecture_full.md`

## Models And Callable Artifacts

- `models/tokenomics_engine_model.json`
- `workflows/tokenomic_runtime_workflow.yaml`
- `benchmarks/tokenomics_benchmark_protocol.json`
- `benchmarks/tokenomics_seed_tasks.jsonl`
- `artifacts/agent_injection_prompt.md`
- `artifacts/tokenomics_callable_scorer.py`

## Boundary

Authority state: `INTERNAL_RESEARCH / BENCHMARK_PENDING`.

The papers include full models, formulas, workflows, and callable artifacts. They do not claim empirical superiority, production deployment, legal filing, or live notarization.
