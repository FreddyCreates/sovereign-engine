# Release Boundaries

## 2026-05-14: Foundation Floor Packet

- Public-safe:
  - Foundation Floor as an internal design thesis for bounded heavy compute
  - Separation principle: heavy synthesis should not directly append canonical memory
  - Explicit caution that proof, deployment, and notarization are not yet established
- Internal-only:
  - Actual mediation logic
  - Canonical memory schemas and vault pathways
  - Authority enforcement policies
  - Side-channel controls and review workflow details
  - Chain target plans, signer material, and any secrets
- Blocked release language:
  - Verified implementation
  - Runtime law adoption
  - Theorem proof
  - Deployment-ready status
  - Notarized or externally registered claims

## 2026-05-14 Extension Boundary Notes

- Allowed added language:
  - prepared for possible notarization
  - staged protocol candidate
  - local-hash-only continuity framing
- Still blocked:
  - NOTARY_READY unless artifact freeze and operator approval are recorded
  - notarized, externally witnessed, chain-recorded, or receipt-backed unless receipt is attached
  - deployment-ready, production deployment, or live-runtime language unless manifest, rollback plan, and evidence exist

## 2026-05-14 Archive Render Boundary Notes

- Archive-grade rendering:
  - may include theorem-candidate framing, objections, proof gaps, deployment translation, and appendix references
  - remains internal archive material
- Internal research rendering:
  - may be more operational and direct about review posture, claim posture, and next validation steps
  - remains internal-only
- Public-safe rendering:
  - may describe bounded heavy compute, protected canonical memory, and architectural caution
  - may not include internal routing logic, authority enforcement mechanism, canonical schema detail, or signer / chain detail
- Still blocked after packet completion:
  - public claims of theorem proof
  - public claims of implementation enforcement
  - public claims of deployment
  - notarized or chain-recorded language

## 2026-05-14 Token Adapter Boundary Notes

- Allowed internal language:
  - placeholder token adapter
  - token-intent intake
  - internal ledger receipt
  - awaiting activation
- Blocked language:
  - live payments
  - custody
  - redemption
  - external transfer finality
  - production token economy activation

## 2026-05-14 arXiv Polyglot Portfolio Boundary Notes

- Public-safe release framing:
  - preprint draft
  - architecture proposal
  - formal framework
  - staged optimization model
  - benchmark methodology
- Public claims intentionally softened:
  - strong cost-reduction percentages treated as provisional internal observations or design targets
  - mathematical hierarchy language treated as a research program unless proof or benchmark support is provided
- Overlap discipline for related submissions:
  - architecture narrative belongs primarily to `Architectura Polyglotta`
  - semantics narrative belongs primarily to `Semantica Polyglotta`
  - Julia hierarchy narrative belongs primarily to `Hierarchia Juliae`
  - routing and benchmark narrative belongs primarily to `Terminalia Intelligens`

## 2026-06-14 Tokenomics Full Research Surface Boundary Notes

- Public-safe:
  - Tokenomics as proposed cognitive-return-per-token framework
  - CRPT as candidate metric
  - benchmark harness as proposed validation method
  - compression fidelity and salience allocation as research concepts
- Internal-controlled:
  - exact model stack as agent-runtime substrate
  - agent injection prompt
  - benchmark protocol and seed tasks until reviewed
  - runtime-control workflow and deployment implications
- Blocked release language:
  - verified Tokenomics superiority
  - production runtime controller
  - legally filed, patented, or secured
  - live notarized or chain-recorded
  - peer-reviewed or accepted
- Promotion requirements:
  - completed benchmark records
  - expanded prior-art/citation review
  - operator approval for exact formula disclosure
  - hash manifest update before public release

## 2026-06-16 AURUM ICP Forge Console Boundary Notes

- Public-safe:
  - AURUM ICP Forge Console as local-first ICP operator product concept
  - `icp-cli` lifecycle wrapper as product architecture
  - local proof packet and promotion-gate concept
  - mainnet-blocked posture
- Internal-controlled:
  - identity selection policy
  - cycles wallet policy
  - production deploy worker
  - subnet targeting and migration controls
  - raw deploy logs before redaction
- Blocked release language:
  - live deployment executed
  - mainnet-ready or mainnet-deployed
  - cycles wallet custody
  - chain-notarized deployment
  - certified canister state
- Release state:
  - working paper and local implementation may circulate internally
  - public summary must say local implementation only unless live receipts are attached
