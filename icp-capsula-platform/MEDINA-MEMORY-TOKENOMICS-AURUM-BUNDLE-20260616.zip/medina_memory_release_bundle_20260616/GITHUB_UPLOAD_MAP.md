# GitHub Upload Map

Target repo requested: `ItsNotAILABS/MedinaMemorySystems`.

Current blocker: the ChatGPT workspace pushed to its configured backend remote, but direct GitHub HTTPS is blocked in this container and the GitHub connector exposed here is read-only for repository contents. The files are therefore not yet visible at GitHub blob URLs and will 404 until uploaded/pushed from a GitHub-capable environment.

## Paths to upload into MedinaMemorySystems

Upload the `thesis/` folder to the repository root:

- `thesis/tokenomics/`
- `thesis/aurum_icp_forge/`
- `thesis/claim-ledger.md`
- `thesis/deployment-translation-history.md`
- `thesis/proof-ledger.md`
- `thesis/release-boundaries.md`
- `thesis/thesis-lineage.md`

Optional standalone repo package:

- `tokenomics_production_repo/`

## Expected GitHub URLs after upload

- `https://github.com/ItsNotAILABS/MedinaMemorySystems/blob/main/thesis/tokenomics/README.md`
- `https://github.com/ItsNotAILABS/MedinaMemorySystems/blob/main/thesis/aurum_icp_forge/README.md`
- `https://github.com/ItsNotAILABS/MedinaMemorySystems/blob/main/thesis/aurum_icp_forge/papers/aurum_icp_forge_console_working_paper.md`
- `https://github.com/ItsNotAILABS/MedinaMemorySystems/blob/main/thesis/tokenomics/papers/tokenomics_measurement_theory_full.md`

## Verification command after real GitHub push

```bash
git clone https://github.com/ItsNotAILABS/MedinaMemorySystems.git
cd MedinaMemorySystems
ls thesis/tokenomics thesis/aurum_icp_forge
PYTHONPATH=thesis/aurum_icp_forge/src python thesis/aurum_icp_forge/tests/run_tests.py
python thesis/tokenomics/artifacts/tokenomics_callable_scorer.py --tokens 1000 --dq 4 --act 4 --risk 4 --reuse 3 --learn 3 --accuracy 4 --waste 1
```
