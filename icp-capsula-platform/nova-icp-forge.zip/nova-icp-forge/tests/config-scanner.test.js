const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { scanIcpConfig } = require("../src/engines/checks/config-scanner");

test("passes a simple local config", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "nova-config-"));
  fs.writeFileSync(path.join(root, "icp.yaml"), "canisters: []\n");
  const result = scanIcpConfig(root);
  assert.equal(result.status, "passed");
});

test("blocks connected/mainnet config terms in v0", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "nova-config-"));
  fs.writeFileSync(path.join(root, "icp.yaml"), "networks:\n  - name: ic\n    mode: connected\n");
  const result = scanIcpConfig(root);
  assert.equal(result.status, "blocked");
  assert.ok(result.blockers.length >= 1);
});
