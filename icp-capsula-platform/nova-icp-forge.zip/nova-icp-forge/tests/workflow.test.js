const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const { loadNovaConfig } = require("../src/config/nova-config");
const { deployLocalWorkflow } = require("../src/commands/workflows");

const root = path.resolve(__dirname, "..");
const config = loadNovaConfig(root);

test("dry-run deploy workflow produces proof", async () => {
  const projectRoot = path.join(config.projectsDir, "dry-run-demo");
  fs.mkdirSync(projectRoot, { recursive: true });
  fs.writeFileSync(path.join(projectRoot, "icp.yaml"), "canisters: []\n");
  const result = await deployLocalWorkflow(config, projectRoot, { dryRun: true, runId: "test_dry_run" });
  assert.equal(result.status, "passed");
  assert.equal(result.commands.length, 2);
  assert.ok(fs.existsSync(result.proof.proofPath));
});
