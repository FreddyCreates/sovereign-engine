const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { discoverLocalCanisters } = require("../src/engines/canister/canister-discovery");
const { generateProofRecord } = require("../src/engines/proof/proof-generator");

test("discovers local canister mappings", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "nova-project-"));
  const mappingDir = path.join(root, ".icp/cache/mappings");
  fs.mkdirSync(mappingDir, { recursive: true });
  fs.writeFileSync(path.join(mappingDir, "local.ids.json"), JSON.stringify({
    backend: "aaaaa-aa",
    frontend: "bbbbb-bb"
  }));
  const result = discoverLocalCanisters(root);
  assert.equal(result.status, "found");
  assert.equal(result.canisters.length, 2);
  assert.ok(result.mappingSha256);
});

test("generates proof record and index", () => {
  const proofRoot = fs.mkdtempSync(path.join(os.tmpdir(), "nova-proof-"));
  const result = generateProofRecord({
    proofRoot,
    project: { id: "project_demo", name: "demo", icpYamlSha256: "abc" },
    deployRun: { id: "run_demo", status: "passed", environment: "local" },
    commands: [{ intent: "deploy_local", exitCode: 0 }],
    canisterDiscovery: { status: "missing", canisters: [] },
    gateResults: []
  });
  assert.ok(fs.existsSync(result.proofPath));
  assert.ok(fs.existsSync(path.join(proofRoot, "proof-index.json")));
  assert.equal(result.proof.schema_version, "nova.icp.proof.v0");
});
