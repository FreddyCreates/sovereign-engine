const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { assertContainedPath, validateProjectName } = require("../src/engines/workspace/workspace-resolver");

test("allows paths under workspace", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "nova-ws-"));
  const inside = path.join(root, "project");
  fs.mkdirSync(inside);
  assert.equal(assertContainedPath(root, inside), inside);
});

test("rejects paths outside workspace", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "nova-ws-"));
  assert.throws(() => assertContainedPath(root, "/etc/passwd"), /escapes/);
});

test("validates safe project names", () => {
  assert.equal(validateProjectName("demo_app-1"), "demo_app-1");
  assert.throws(() => validateProjectName("../bad"), /Project name/);
});
