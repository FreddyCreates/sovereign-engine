const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("path");
const { loadNovaConfig } = require("../src/config/nova-config");
const { loadCommandPolicy, compileCommand } = require("../src/engines/policy/command-policy");

const root = path.resolve(__dirname, "..");
const config = loadNovaConfig(root);
const policy = loadCommandPolicy(config.policyPath, config.denyPolicyPath);

test("compiles an allowed local intent", () => {
  const compiled = compileCommand(policy, {
    intent: "project_show",
    cwd: config.projectsDir,
    environment: "local"
  });
  assert.deepEqual(compiled.argv, ["icp", "project", "show"]);
});

test("rejects unknown command intent", () => {
  assert.throws(() => compileCommand(policy, {
    intent: "deploy_mainnet",
    cwd: config.projectsDir,
    environment: "local"
  }), /not allowed/);
});

test("rejects nonlocal environment", () => {
  assert.throws(() => compileCommand(policy, {
    intent: "deploy_local",
    cwd: config.projectsDir,
    environment: "ic"
  }), /local environment/);
});

test("rejects shell metacharacters in project name", () => {
  assert.throws(() => compileCommand(policy, {
    intent: "scaffold_project",
    cwd: config.projectsDir,
    environment: "local",
    args: { project_name: "demo;rm-rf" }
  }), /metacharacter/);
});

test("rejects unexpected command arguments", () => {
  assert.throws(() => compileCommand(policy, {
    intent: "scaffold_project",
    cwd: config.projectsDir,
    environment: "local",
    args: { project_name: "demo", identity: "prod" }
  }), /not allowed/);
});
