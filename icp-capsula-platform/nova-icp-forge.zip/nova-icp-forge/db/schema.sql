create table if not exists projects (
  id text primary key,
  name text not null,
  root_path text not null,
  icp_yaml_path text,
  icp_yaml_sha256 text,
  creation_mode text not null check (creation_mode in ('scaffolded', 'imported')),
  gate_status text not null,
  created_at text not null,
  updated_at text not null
);

create table if not exists deploy_runs (
  id text primary key,
  project_id text not null references projects(id),
  environment text not null default 'local',
  network text not null default 'local',
  status text not null check (status in ('queued', 'running', 'passed', 'failed', 'blocked')),
  dry_run integer not null default 1,
  started_at text,
  completed_at text,
  proof_record_id text
);

create table if not exists command_events (
  id text primary key,
  deploy_run_id text not null references deploy_runs(id),
  sequence integer not null,
  intent text not null,
  argv_json text not null,
  cwd text not null,
  exit_code integer,
  stdout_path text,
  stderr_path text,
  stdout_sha256 text,
  stderr_sha256 text,
  argv_sha256 text,
  started_at text not null,
  completed_at text
);

create table if not exists canister_records (
  id text primary key,
  project_id text not null references projects(id),
  deploy_run_id text references deploy_runs(id),
  environment text not null,
  canister_name text not null,
  canister_id text not null,
  mapping_source_path text not null,
  mapping_sha256 text not null,
  discovered_at text not null
);

create table if not exists proof_records (
  id text primary key,
  project_id text not null references projects(id),
  deploy_run_id text not null references deploy_runs(id),
  proof_path text not null,
  proof_sha256 text not null,
  previous_proof_hash text,
  status text not null check (status in ('draft', 'valid', 'invalid')),
  created_at text not null
);
