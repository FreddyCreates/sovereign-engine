---
name: nova-icp-forge
description: Use when building, validating, or operating Nova-native Internet Computer workflows with icp-cli, including local project intake, deploy-local runs, canister discovery, command policy gates, and proof records.
---

# Nova ICP Forge

Use this skill when the task involves Nova ICP Forge, `Nova.toml`, `icp-cli`, Internet Computer project scaffolding, local deploys, canister discovery, command gates, or proof records.

## Workflow

1. Load `Nova.toml`.
2. Keep v0 local-first unless the user explicitly asks for a future architecture, not execution.
3. Use command intents, not raw shell strings.
4. Check workspace containment before reading, writing, or executing.
5. Validate `icp.yaml` presence before project commands.
6. Run local commands only through the policy engine.
7. Discover canisters from `.icp/cache/mappings/local.ids.json`.
8. Generate a proof record after every meaningful run.

## Hard v0 Blocks

Block mainnet, subnet, identity mutation, token transfer, cycles movement, canister delete, snapshot restore, migration, reinstall, and arbitrary shell execution.

## Local Commands

Use:

```bash
node bin/nova-icp-forge.js doctor
node bin/nova-icp-forge.js deploy-local --project ./workspaces/projects/<name>
```

Add `--execute` only when the operator wants real local execution.

## References

- `references/icp-cli-v03-brief.md` for command and config facts.
