# ICP CLI v0.3 Brief

Official documentation root: https://cli.internetcomputer.org/0.3/

Relevant facts:

- Project root contains `icp.yaml`.
- `icp deploy` runs build, create, environment-variable injection, install, and sync.
- Local network starts with `icp network start -d`.
- Local network status can be checked with `icp network status --json`.
- Local canister mappings live at `.icp/cache/mappings/<environment>.ids.json`.
- Connected/mainnet mappings live at `.icp/data/mappings/<environment>.ids.json`.
- Deploying to mainnet uses `icp deploy -e ic`.
- Identity, cycles, subnet, snapshot, migration, and reinstall commands require stronger gates than v0.
