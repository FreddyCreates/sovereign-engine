const path = require("path");
const { readTomlLite } = require("../utils/toml-lite");

function loadNovaConfig(rootDir) {
  const configPath = path.join(rootDir, "Nova.toml");
  const config = readTomlLite(configPath);
  const workspaceRoot = path.resolve(rootDir, config.workspace?.root || "workspaces");

  return {
    rootDir,
    configPath,
    raw: config,
    workspaceRoot,
    projectsDir: path.resolve(rootDir, config.workspace?.projects || "workspaces/projects"),
    artifactsDir: path.resolve(rootDir, config.workspace?.artifacts || "workspaces/artifacts"),
    logsDir: path.resolve(rootDir, config.workspace?.logs || "workspaces/artifacts/logs"),
    proofsDir: path.resolve(rootDir, config.workspace?.proofs || "workspaces/artifacts/proofs"),
    configsDir: path.resolve(rootDir, config.workspace?.configs || "workspaces/artifacts/configs"),
    mappingsDir: path.resolve(rootDir, config.workspace?.mappings || "workspaces/artifacts/mappings"),
    policyPath: path.resolve(rootDir, config.policy?.command_policy || ".nova/policies/icp-local-v0.toml"),
    denyPolicyPath: path.resolve(rootDir, config.policy?.deny_policy || ".nova/policies/blocked-connected-v0.toml"),
    localMappingPath: config.icp?.local_mapping || ".icp/cache/mappings/local.ids.json",
    connectedNetworksEnabled: Boolean(config.icp?.connected_networks_enabled)
  };
}

module.exports = { loadNovaConfig };
