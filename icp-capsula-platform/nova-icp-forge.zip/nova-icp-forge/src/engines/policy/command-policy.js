const path = require("path");
const { readTomlLite } = require("../../utils/toml-lite");
const { SafetyError, ValidationError } = require("../../utils/errors");

const SHELL_META = /[;&|`$<>{}[\]*?!\n\r]/;
const BLOCKED_ARG_PREFIXES = [
  "--identity",
  "--identity-password-file",
  "--network",
  "--environment",
  "--wallet",
  "--subnet",
  "--provider",
  "--replica",
  "--ledger",
  "--mainnet",
  "--cycles-wallet"
];

function loadCommandPolicy(policyPath, denyPolicyPath) {
  const policy = readTomlLite(policyPath);
  const denyPolicy = readTomlLite(denyPolicyPath);
  const commands = new Map();
  for (const command of policy.commands || []) {
    commands.set(command.intent, command);
  }
  return {
    version: policy.version || "nova.icp.command-policy.v0",
    binary: policy.binary || "icp",
    timeoutMs: policy.timeout_ms || 120000,
    maxOutputBytes: policy.max_output_bytes || 1048576,
    commands,
    deniedFlags: new Set(denyPolicy.blocked_flags || []),
    deniedWords: (denyPolicy.blocked_words || []).map((word) => String(word).toLowerCase()),
    deniedEnv: new Set(denyPolicy.blocked_env || [])
  };
}

function validateArgValue(name, value) {
  const text = String(value ?? "");
  if (!text) throw new ValidationError("Required command argument is empty", { name });
  if (text.includes("\0")) throw new SafetyError("Argument contains null byte", { name });
  if (SHELL_META.test(text)) throw new SafetyError("Argument contains blocked shell metacharacter", { name });
  if (text.startsWith("-")) throw new SafetyError("Positional argument may not begin with a flag marker", { name });
  if (name === "project_name" && !/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(text)) {
    throw new ValidationError("Invalid project_name", { value: text });
  }
  return text;
}

function assertNoBlockedToken(argv, policy) {
  const lowered = argv.map((item) => String(item).toLowerCase());
  for (const item of argv) {
    const text = String(item);
    for (const flag of BLOCKED_ARG_PREFIXES) {
      if (text === flag || text.startsWith(flag + "=")) {
        throw new SafetyError("Blocked authority-bearing flag in argv", { flag });
      }
    }
    if (policy.deniedFlags.has(text)) {
      throw new SafetyError("Blocked flag in argv", { flag: text });
    }
  }
  for (const deniedWord of policy.deniedWords) {
    if (lowered.some((item) => item.includes(deniedWord))) {
      throw new SafetyError("Blocked authority-bearing word in argv", { deniedWord });
    }
  }
}

function compileCommand(policy, request) {
  if (request.environment !== "local") {
    throw new SafetyError("v0 only allows local environment", { environment: request.environment });
  }
  const command = policy.commands.get(request.intent);
  if (!command) {
    throw new SafetyError("Command intent is not allowed in v0", { intent: request.intent });
  }
  const allowedArgs = new Set(command.allowed_args || []);
  const args = request.args || {};
  for (const key of Object.keys(args)) {
    if (!allowedArgs.has(key)) {
      throw new SafetyError("Command argument is not allowed for intent", { intent: request.intent, key });
    }
  }

  const argv = (command.argv || []).map((part) => {
    if (typeof part === "string" && part.startsWith("$")) {
      const name = part.slice(1);
      return validateArgValue(name, args[name]);
    }
    return String(part);
  });

  assertNoBlockedToken(argv, policy);
  return {
    intent: request.intent,
    argv,
    binary: argv[0],
    args: argv.slice(1),
    requiresIcpYaml: Boolean(command.requires_icp_yaml),
    policyVersion: policy.version,
    timeoutMs: policy.timeoutMs,
    maxOutputBytes: policy.maxOutputBytes
  };
}

function sanitizedEnvironment(baseEnv = process.env, policy) {
  const env = {};
  const allowedPassThrough = ["PATH", "LANG", "LC_ALL", "TERM"];
  for (const key of allowedPassThrough) {
    if (baseEnv[key]) env[key] = baseEnv[key];
  }
  for (const key of policy.deniedEnv) {
    delete env[key];
  }
  env.DFX_NETWORK = "local";
  env.NODE_ENV = baseEnv.NODE_ENV || "production";
  return env;
}

module.exports = { loadCommandPolicy, compileCommand, sanitizedEnvironment };
