const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const { sha256File, sha256Json } = require("../../utils/hash");
const { redactText } = require("../../utils/redact");
const { SafetyError } = require("../../utils/errors");
const { ensureDir, assertContainedPath, assertIcpYaml } = require("../workspace/workspace-resolver");

function makeRunId(prefix = "run") {
  return `${prefix}_${new Date().toISOString().replace(/[:.]/g, "-")}_${Math.random().toString(16).slice(2, 8)}`;
}

function collectLimited(stream, maxBytes) {
  const chunks = [];
  let total = 0;
  let truncated = false;
  stream.on("data", (chunk) => {
    total += chunk.length;
    if (total <= maxBytes) {
      chunks.push(chunk);
    } else {
      truncated = true;
      const remaining = Math.max(0, maxBytes - Buffer.concat(chunks).length);
      if (remaining > 0) chunks.push(chunk.subarray(0, remaining));
    }
  });
  return new Promise((resolve) => {
    stream.on("end", () => resolve({ buffer: Buffer.concat(chunks), truncated }));
  });
}

async function runCompiledCommand(options) {
  const {
    config,
    compiled,
    cwd,
    env,
    runId = makeRunId(compiled.intent),
    dryRun = true
  } = options;

  const containedCwd = assertContainedPath(config.workspaceRoot, cwd, "command cwd");
  if (compiled.requiresIcpYaml) assertIcpYaml(containedCwd);

  const logDir = path.join(config.logsDir, runId);
  ensureDir(logDir);

  const commandEvent = {
    id: `${runId}_event_0`,
    runId,
    sequence: 0,
    intent: compiled.intent,
    argv: compiled.argv,
    cwd: containedCwd,
    dryRun,
    startedAt: new Date().toISOString(),
    policyVersion: compiled.policyVersion
  };

  if (dryRun) {
    const stdoutPath = path.join(logDir, "stdout.txt");
    const stderrPath = path.join(logDir, "stderr.txt");
    fs.writeFileSync(stdoutPath, `DRY RUN: ${compiled.argv.join(" ")}\n`);
    fs.writeFileSync(stderrPath, "");
    commandEvent.completedAt = new Date().toISOString();
    commandEvent.exitCode = 0;
    commandEvent.stdoutPath = stdoutPath;
    commandEvent.stderrPath = stderrPath;
    commandEvent.stdoutSha256 = sha256File(stdoutPath);
    commandEvent.stderrSha256 = sha256File(stderrPath);
    commandEvent.argvSha256 = sha256Json(compiled.argv);
    return { status: "passed", runId, commandEvent };
  }

  const child = spawn(compiled.binary, compiled.args, {
    cwd: containedCwd,
    env,
    shell: false,
    stdio: ["ignore", "pipe", "pipe"]
  });

  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    child.kill("SIGTERM");
  }, compiled.timeoutMs);

  const stdoutPromise = collectLimited(child.stdout, compiled.maxOutputBytes);
  const stderrPromise = collectLimited(child.stderr, compiled.maxOutputBytes);
  const exitCode = await new Promise((resolve, reject) => {
    child.on("error", reject);
    child.on("close", (code) => resolve(code ?? 1));
  });
  clearTimeout(timer);

  const [stdout, stderr] = await Promise.all([stdoutPromise, stderrPromise]);
  const stdoutRedacted = redactText(stdout.buffer.toString("utf8"));
  const stderrRedacted = redactText(stderr.buffer.toString("utf8"));
  if (stdoutRedacted.redactionApplied || stderrRedacted.redactionApplied) {
    commandEvent.redactionApplied = true;
  }

  const stdoutPath = path.join(logDir, "stdout.txt");
  const stderrPath = path.join(logDir, "stderr.txt");
  fs.writeFileSync(stdoutPath, stdoutRedacted.text);
  fs.writeFileSync(stderrPath, stderrRedacted.text);

  commandEvent.completedAt = new Date().toISOString();
  commandEvent.exitCode = timedOut ? 124 : exitCode;
  commandEvent.timedOut = timedOut;
  commandEvent.stdoutPath = stdoutPath;
  commandEvent.stderrPath = stderrPath;
  commandEvent.stdoutSha256 = sha256File(stdoutPath);
  commandEvent.stderrSha256 = sha256File(stderrPath);
  commandEvent.argvSha256 = sha256Json(compiled.argv);
  commandEvent.stdoutTruncated = stdout.truncated;
  commandEvent.stderrTruncated = stderr.truncated;

  return {
    status: commandEvent.exitCode === 0 ? "passed" : "failed",
    runId,
    commandEvent
  };
}

module.exports = { runCompiledCommand, makeRunId };
