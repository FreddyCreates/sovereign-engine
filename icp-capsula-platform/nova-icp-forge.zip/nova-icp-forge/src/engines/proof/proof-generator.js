const fs = require("fs");
const path = require("path");
const { sha256File, sha256Json } = require("../../utils/hash");
const { ensureDir } = require("../workspace/workspace-resolver");

function readPreviousProofHash(proofRoot) {
  const indexPath = path.join(proofRoot, "proof-index.json");
  if (!fs.existsSync(indexPath)) return null;
  try {
    const index = JSON.parse(fs.readFileSync(indexPath, "utf8"));
    return index.latestProofHash || null;
  } catch {
    return null;
  }
}

function writeProofIndex(proofRoot, proofPath, proofHash) {
  const indexPath = path.join(proofRoot, "proof-index.json");
  fs.writeFileSync(indexPath, JSON.stringify({
    latestProofPath: proofPath,
    latestProofHash: proofHash,
    updatedAt: new Date().toISOString()
  }, null, 2));
}

function writeAtomicJson(filePath, value) {
  ensureDir(path.dirname(filePath));
  const tmpPath = `${filePath}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(value, null, 2));
  fs.renameSync(tmpPath, filePath);
}

function generateProofRecord(input) {
  const now = new Date().toISOString();
  const previousProofHash = readPreviousProofHash(input.proofRoot);
  const proof = {
    schema_version: "nova.icp.proof.v0",
    generated_at: now,
    project: input.project,
    deploy_run: input.deployRun,
    commands: input.commands || [],
    effective_config: input.effectiveConfig || null,
    canister_mappings: input.canisterDiscovery || null,
    gate_results: input.gateResults || [],
    validation: {
      icp_yaml_present: Boolean(input.project?.icpYamlSha256),
      command_events_recorded: Boolean((input.commands || []).length),
      canister_mapping_found: input.canisterDiscovery?.status === "found",
      local_only: true
    },
    previous_proof_hash: previousProofHash
  };
  proof.proof_hash_preview = sha256Json(proof);

  const proofPath = path.join(input.proofRoot, `${input.deployRun.id}.proof.json`);
  writeAtomicJson(proofPath, proof);
  const proofHash = sha256File(proofPath);
  writeProofIndex(input.proofRoot, proofPath, proofHash);
  return { proofPath, proofHash, proof };
}

module.exports = { generateProofRecord, writeAtomicJson };
