const fs = require("fs");
const path = require("path");

const BLOCKERS = [
  { id: "mainnet_word", pattern: /\b(mainnet|production)\b/i },
  { id: "ic_environment", pattern: /(^|\s)(ic\s*:|-\s*name\s*:\s*ic\b|\benvironment\s*:\s*ic\b)/i },
  { id: "connected_network", pattern: /\bmode\s*:\s*connected\b/i },
  { id: "identity_reference", pattern: /\b(identity|identity-password-file|seed|mnemonic|pem)\b/i },
  { id: "wallet_cycles", pattern: /\b(wallet|cycles|ledger|transfer|top-up)\b/i },
  { id: "subnet_reference", pattern: /\bsubnet\b/i },
  { id: "reinstall_mode", pattern: /\bmode\s*:\s*reinstall\b/i },
  { id: "snapshot_restore", pattern: /\bsnapshot\s+restore\b/i }
];

function scanIcpConfig(projectRoot) {
  const icpYamlPath = path.join(projectRoot, "icp.yaml");
  if (!fs.existsSync(icpYamlPath)) {
    return {
      status: "missing",
      blockers: [{ id: "icp_yaml_missing", reason: "icp.yaml not found" }]
    };
  }

  const text = fs.readFileSync(icpYamlPath, "utf8");
  const blockers = [];
  for (const blocker of BLOCKERS) {
    if (blocker.pattern.test(text)) {
      blockers.push({
        id: blocker.id,
        reason: `Blocked v0 config pattern: ${blocker.id}`
      });
    }
  }

  return {
    status: blockers.length ? "blocked" : "passed",
    icpYamlPath,
    blockers
  };
}

module.exports = { scanIcpConfig, BLOCKERS };
