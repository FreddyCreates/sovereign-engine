const fs = require("fs");
const path = require("path");
const { SafetyError, ValidationError } = require("../../utils/errors");

const FORBIDDEN_ROOTS = new Set(["/", "/root", "/home", "/tmp", "/etc", "/var", "/usr"]);

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
  return dirPath;
}

function assertSafeWorkspaceRoot(workspaceRoot) {
  const resolved = path.resolve(workspaceRoot);
  if (FORBIDDEN_ROOTS.has(resolved)) {
    throw new SafetyError("Workspace root is too broad for command execution", { workspaceRoot: resolved });
  }
  ensureDir(resolved);
  return fs.realpathSync(resolved);
}

function realpathOrParent(candidatePath) {
  const resolved = path.resolve(candidatePath);
  if (fs.existsSync(resolved)) return fs.realpathSync(resolved);
  const parent = path.dirname(resolved);
  if (!fs.existsSync(parent)) return realpathOrParent(parent);
  return path.join(fs.realpathSync(parent), path.basename(resolved));
}

function assertContainedPath(workspaceRoot, candidatePath, label = "path") {
  const root = assertSafeWorkspaceRoot(workspaceRoot);
  const target = realpathOrParent(candidatePath);
  if (target !== root && !target.startsWith(root + path.sep)) {
    throw new SafetyError(`${label} escapes Nova workspace`, { root, target });
  }
  if (target.includes(`${path.sep}.git${path.sep}`) || target.endsWith(`${path.sep}.git`)) {
    throw new SafetyError(`${label} points into .git`, { target });
  }
  return target;
}

function validateProjectName(projectName) {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(projectName || "")) {
    throw new ValidationError("Project name must be 1-64 safe characters", { projectName });
  }
  return projectName;
}

function projectPath(config, projectName) {
  validateProjectName(projectName);
  const target = path.join(config.projectsDir, projectName);
  return assertContainedPath(config.workspaceRoot, target, "project path");
}

function assertIcpYaml(projectRoot) {
  const marker = path.join(projectRoot, "icp.yaml");
  if (!fs.existsSync(marker)) {
    throw new ValidationError("Project does not contain icp.yaml", { projectRoot });
  }
  return marker;
}

function makeRunDirs(config, runId) {
  const runRoot = assertContainedPath(config.workspaceRoot, path.join(config.artifactsDir, "runs", runId), "run root");
  const logsDir = assertContainedPath(config.workspaceRoot, path.join(config.logsDir, runId), "logs dir");
  const proofDir = assertContainedPath(config.workspaceRoot, path.join(config.proofsDir, runId), "proof dir");
  ensureDir(runRoot);
  ensureDir(logsDir);
  ensureDir(proofDir);
  return { runRoot, logsDir, proofDir };
}

module.exports = {
  ensureDir,
  assertSafeWorkspaceRoot,
  assertContainedPath,
  validateProjectName,
  projectPath,
  assertIcpYaml,
  makeRunDirs
};
