const fs = require("fs");
const path = require("path");
const { sha256File } = require("../../utils/hash");

function discoverLocalCanisters(projectRoot, localMappingPath = ".icp/cache/mappings/local.ids.json") {
  const mappingPath = path.join(projectRoot, localMappingPath);
  if (!fs.existsSync(mappingPath)) {
    return {
      status: "missing",
      mappingPath,
      mappingSha256: null,
      canisters: []
    };
  }

  const mapping = JSON.parse(fs.readFileSync(mappingPath, "utf8"));
  const canisters = Object.entries(mapping).map(([name, canisterId]) => ({
    name,
    canisterId: String(canisterId)
  }));

  return {
    status: "found",
    mappingPath,
    mappingSha256: sha256File(mappingPath),
    canisters
  };
}

module.exports = { discoverLocalCanisters };
