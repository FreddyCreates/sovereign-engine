const fs = require("fs");
const path = require("path");
const { assertContainedPath, assertIcpYaml } = require("../workspace/workspace-resolver");
const { scanIcpConfig } = require("../checks/config-scanner");

function gateResult(gate, status, reason) {
  return {
    gate,
    status,
    reason,
    checkedAt: new Date().toISOString()
  };
}

function evaluateProjectIntake(config, projectRoot, mode = "import") {
  const results = [];
  try {
    assertContainedPath(config.workspaceRoot, projectRoot, "project root");
    results.push(gateResult("workspace_path_contained", "passed"));
  } catch (error) {
    results.push(gateResult("workspace_path_contained", "blocked", error.message));
  }
  if (mode === "import") {
    const icpYaml = path.join(projectRoot, "icp.yaml");
    results.push(gateResult("icp_yaml_present_for_import", fs.existsSync(icpYaml) ? "passed" : "blocked"));
  }
  const scan = scanIcpConfig(projectRoot);
  results.push(gateResult("config_scanned_for_v0_blockers", scan.status === "blocked" ? "blocked" : "passed", scan.blockers?.map((item) => item.id).join(", ") || undefined));
  results.push(gateResult("connected_networks_disabled", config.connectedNetworksEnabled ? "blocked" : "passed"));
  return results;
}

function evaluateLocalDeploy(config, projectRoot, compiledCommand) {
  const results = [];
  results.push(gateResult("environment_is_local", "passed"));
  results.push(gateResult("command_intent_allowed", compiledCommand ? "passed" : "blocked"));
  try {
    assertContainedPath(config.workspaceRoot, projectRoot, "project root");
    results.push(gateResult("workspace_path_contained", "passed"));
  } catch (error) {
    results.push(gateResult("workspace_path_contained", "blocked", error.message));
  }
  try {
    assertIcpYaml(projectRoot);
    results.push(gateResult("icp_yaml_present", "passed"));
  } catch (error) {
    results.push(gateResult("icp_yaml_present", "blocked", error.message));
  }
  const scan = scanIcpConfig(projectRoot);
  results.push(gateResult("config_scanned_for_v0_blockers", scan.status === "blocked" ? "blocked" : "passed", scan.blockers?.map((item) => item.id).join(", ") || undefined));
  results.push(gateResult("mainnet_flags_absent", "passed"));
  return results;
}

function statusFromGateResults(results) {
  if (results.some((result) => result.status === "blocked" || result.status === "failed")) return "blocked";
  return "passed";
}

module.exports = { gateResult, evaluateProjectIntake, evaluateLocalDeploy, statusFromGateResults };
