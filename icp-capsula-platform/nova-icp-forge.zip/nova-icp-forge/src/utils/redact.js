const REDACTION = "[REDACTED]";

const PATTERNS = [
  /-----BEGIN [^-]+PRIVATE KEY-----[\s\S]*?-----END [^-]+PRIVATE KEY-----/g,
  /\b(seed phrase|mnemonic)\b\s*[:=]\s*[^\n]+/gi,
  /\b(token|secret|password|authorization)\b\s*[:=]\s*[^\n]+/gi,
  /\bBearer\s+[A-Za-z0-9._~+/=-]+/g,
  /\b\/(?:root|home|Users)\/[^\s'"]+/g
];

function redactText(input) {
  let output = String(input ?? "");
  let redactionApplied = false;

  for (const pattern of PATTERNS) {
    output = output.replace(pattern, () => {
      redactionApplied = true;
      return REDACTION;
    });
  }

  return { text: output, redactionApplied };
}

module.exports = { redactText, REDACTION };
