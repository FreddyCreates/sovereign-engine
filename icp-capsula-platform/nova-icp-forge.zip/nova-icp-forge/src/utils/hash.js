const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

function sha256Text(value) {
  return crypto.createHash("sha256").update(String(value)).digest("hex");
}

function sha256Json(value) {
  return sha256Text(JSON.stringify(value, stableJsonReplacer));
}

function stableJsonReplacer(key, value) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return Object.keys(value)
      .sort()
      .reduce((acc, itemKey) => {
        acc[itemKey] = value[itemKey];
        return acc;
      }, {});
  }
  return value;
}

function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  const data = fs.readFileSync(filePath);
  hash.update(data);
  return hash.digest("hex");
}

function fileManifest(root, options = {}) {
  const maxFiles = options.maxFiles || 5000;
  const entries = [];

  function walk(current) {
    if (!fs.existsSync(current)) return;
    const stat = fs.lstatSync(current);
    if (stat.isSymbolicLink()) {
      entries.push({ path: path.relative(root, current), type: "symlink" });
      return;
    }
    if (stat.isDirectory()) {
      for (const name of fs.readdirSync(current).sort()) {
        if (entries.length >= maxFiles) return;
        walk(path.join(current, name));
      }
      return;
    }
    if (stat.isFile()) {
      entries.push({
        path: path.relative(root, current),
        size: stat.size,
        sha256: sha256File(current)
      });
    }
  }

  walk(root);
  return {
    root,
    entries,
    sha256: sha256Json(entries)
  };
}

module.exports = { sha256Text, sha256Json, sha256File, fileManifest };
