class NovaForgeError extends Error {
  constructor(message, code = "NOVA_FORGE_ERROR", details = {}) {
    super(message);
    this.name = this.constructor.name;
    this.code = code;
    this.details = details;
  }
}

class SafetyError extends NovaForgeError {
  constructor(message, details = {}) {
    super(message, "SAFETY_ERROR", details);
  }
}

class ValidationError extends NovaForgeError {
  constructor(message, details = {}) {
    super(message, "VALIDATION_ERROR", details);
  }
}

module.exports = { NovaForgeError, SafetyError, ValidationError };
