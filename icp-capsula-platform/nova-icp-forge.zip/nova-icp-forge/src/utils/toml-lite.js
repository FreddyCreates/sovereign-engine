const fs = require("fs");

function parsePrimitive(raw) {
  const value = raw.trim();
  if (value === "true") return true;
  if (value === "false") return false;
  if (/^-?\d+$/.test(value)) return Number(value);
  if (value.startsWith('"') && value.endsWith('"')) {
    return value.slice(1, -1);
  }
  if (value.startsWith("[") && value.endsWith("]")) {
    const inner = value.slice(1, -1).trim();
    if (!inner) return [];
    return inner
      .split(",")
      .map((item) => parsePrimitive(item.trim()));
  }
  return value;
}

function parseTomlLite(text) {
  const root = {};
  let current = root;
  let currentArrayName = null;
  const logicalLines = [];
  let pending = "";

  for (const originalLine of text.split(/\r?\n/)) {
    const line = originalLine.replace(/#.*$/, "").trim();
    if (!line) continue;
    pending = pending ? `${pending} ${line}` : line;
    const openBrackets = (pending.match(/\[/g) || []).length;
    const closeBrackets = (pending.match(/\]/g) || []).length;
    if (openBrackets > closeBrackets) continue;
    logicalLines.push(pending);
    pending = "";
  }

  for (const line of logicalLines) {

    const arrayMatch = line.match(/^\[\[([A-Za-z0-9_.-]+)\]\]$/);
    if (arrayMatch) {
      const name = arrayMatch[1];
      root[name] ||= [];
      const item = {};
      root[name].push(item);
      current = item;
      currentArrayName = name;
      continue;
    }

    const sectionMatch = line.match(/^\[([A-Za-z0-9_.-]+)\]$/);
    if (sectionMatch) {
      const parts = sectionMatch[1].split(".");
      current = root;
      for (const part of parts) {
        current[part] ||= {};
        current = current[part];
      }
      currentArrayName = null;
      continue;
    }

    const keyValue = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/);
    if (!keyValue) continue;
    const key = keyValue[1];
    current[key] = parsePrimitive(keyValue[2]);
  }

  return root;
}

function readTomlLite(filePath) {
  return parseTomlLite(fs.readFileSync(filePath, "utf8"));
}

module.exports = { parseTomlLite, readTomlLite };
