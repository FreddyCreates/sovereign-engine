const fs = require("fs");
const path = require("path");
const { loadCommandPolicy, compileCommand, sanitizedEnvironment } = require("../engines/policy/command-policy");
const { runCompiledCommand, makeRunId } = require("../engines/runner/command-runner");
const { discoverLocalCanisters } = require("../engines/canister/canister-discovery");
const { generateProofRecord } = require("../engines/proof/proof-generator");
const { evaluateLocalDeploy, statusFromGateResults } = require("../engines/gate/operator-gates");
const { assertContainedPath, assertIcpYaml, ensureDir } = require("../engines/workspace/workspace-resolver");
const { sha256File } = require("../utils/hash");

function loadPolicy(config) {
  return loadCommandPolicy(config.policyPath, config.denyPolicyPath);
}

async function runIntent(config, request, options = {}) {
  const policy = loadPolicy(config);
  const compiled = compileCommand(policy, request);
  const cwd = assertContainedPath(config.workspaceRoot, request.cwd, "command cwd");
  const env = sanitizedEnvironment(process.env, policy);
  return runCompiledCommand({
    config,
    compiled,
    cwd,
    env,
    dryRun: options.dryRun !== false,
    runId: options.runId
  });
}

async function deployLocalWorkflow(config, projectRoot, options = {}) {
  const root = assertContainedPath(config.workspaceRoot, projectRoot, "project root");
  const icpYamlPath = assertIcpYaml(root);
  const policy = loadPolicy(config);
  const runId = options.runId || makeRunId("deploy_local");
  const commands = [];

  const startCommand = compileCommand(policy, { intent: "network_start", cwd: root, environment: "local" });
  const deployCommand = compileCommand(policy, { intent: "deploy_local", cwd: root, environment: "local" });
  const gateResults = evaluateLocalDeploy(config, root, deployCommand);
  if (statusFromGateResults(gateResults) !== "passed") {
    return { status: "blocked", runId, gateResults, commands };
  }

  const env = sanitizedEnvironment(process.env, policy);
  const start = await runCompiledCommand({ config, compiled: startCommand, cwd: root, env, dryRun: options.dryRun !== false, runId });
  commands.push(start.commandEvent);
  const deploy = await runCompiledCommand({ config, compiled: deployCommand, cwd: root, env, dryRun: options.dryRun !== false, runId });
  commands.push(deploy.commandEvent);

  const canisterDiscovery = discoverLocalCanisters(root, config.localMappingPath);
  const proofRoot = path.join(config.proofsDir, runId);
  ensureDir(proofRoot);
  const proofResult = generateProofRecord({
    proofRoot,
    project: {
      id: `project_${path.basename(root)}`,
      name: path.basename(root),
      root,
      icpYamlPath,
      icpYamlSha256: sha256File(icpYamlPath)
    },
    deployRun: {
      id: runId,
      environment: "local",
      network: "local",
      status: deploy.status,
      dryRun: options.dryRun !== false,
      completedAt: new Date().toISOString()
    },
    commands,
    canisterDiscovery,
    gateResults
  });

  return {
    status: deploy.status,
    runId,
    gateResults,
    commands,
    canisterDiscovery,
    proof: proofResult
  };
}

module.exports = { runIntent, deployLocalWorkflow };
