const fs = require("fs");
const path = require("path");
const { sha256File } = require("../utils/hash");
const { projectPath, assertContainedPath, assertIcpYaml, ensureDir, validateProjectName } = require("../engines/workspace/workspace-resolver");
const { evaluateProjectIntake, statusFromGateResults } = require("../engines/gate/operator-gates");

function initProjectRecord(config, input) {
  const mode = input.mode || "import";
  let root;
  if (mode === "scaffold") {
    validateProjectName(input.name);
    root = projectPath(config, input.name);
    ensureDir(root);
  } else {
    root = assertContainedPath(config.workspaceRoot, input.path, "import path");
  }

  const gateResults = evaluateProjectIntake(config, root, mode);
  const gateStatus = statusFromGateResults(gateResults);
  let icpYamlPath = null;
  let icpYamlSha256 = null;
  if (fs.existsSync(path.join(root, "icp.yaml"))) {
    icpYamlPath = assertIcpYaml(root);
    icpYamlSha256 = sha256File(icpYamlPath);
  }

  const record = {
    id: `project_${path.basename(root).replace(/[^A-Za-z0-9_-]/g, "_")}`,
    name: input.name || path.basename(root),
    mode,
    root,
    icpYamlPath,
    icpYamlSha256,
    gateStatus,
    gateResults,
    createdAt: new Date().toISOString()
  };

  const projectRecordPath = path.join(root, ".nova-project.json");
  fs.writeFileSync(projectRecordPath, JSON.stringify(record, null, 2));
  return record;
}

module.exports = { initProjectRecord };
