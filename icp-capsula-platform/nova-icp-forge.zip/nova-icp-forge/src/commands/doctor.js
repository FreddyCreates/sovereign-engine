const fs = require("fs");
const { spawnSync } = require("child_process");

function runDoctor(config) {
  const checks = [];
  checks.push({
    name: "Nova.toml",
    status: fs.existsSync(config.configPath) ? "passed" : "failed",
    detail: config.configPath
  });
  checks.push({
    name: "workspace root",
    status: fs.existsSync(config.workspaceRoot) ? "passed" : "failed",
    detail: config.workspaceRoot
  });

  const version = spawnSync("icp", ["--version"], { encoding: "utf8", shell: false });
  checks.push({
    name: "icp-cli",
    status: version.status === 0 ? "passed" : "warning",
    detail: version.status === 0 ? version.stdout.trim() : "icp not found or not executable in this environment"
  });

  return checks;
}

module.exports = { runDoctor };
