# Nova ICP Forge Tool Catalog

## `nova.icp.doctor`

Checks package health:

```bash
node bin/nova-icp-forge.js doctor
```

## `nova.icp.init_project`

Creates a Nova project record:

```bash
node bin/nova-icp-forge.js init-project --mode import --path ./workspaces/projects/my-project
```

## `nova.icp.deploy_local`

Runs local network start and local deploy through gates.

Dry-run:

```bash
node bin/nova-icp-forge.js deploy-local --project ./workspaces/projects/my-project
```

Execute:

```bash
node bin/nova-icp-forge.js deploy-local --project ./workspaces/projects/my-project --execute
```

## `nova.icp.discover_canisters`

Reads `.icp/cache/mappings/local.ids.json`:

```bash
node bin/nova-icp-forge.js discover --project ./workspaces/projects/my-project
```

## Gate Law

All tools are local-first in v0. Mainnet, subnet, cycles, token, identity mutation, reinstall, delete, migration, and snapshot restore are blocked until future capability levels are intentionally activated.
