# Nova ICP Forge Product Spec

## Product Surface

Nova ICP Forge is the native ICP deployment organ for Nova. It turns `icp-cli` workflows into governed tools that can be invoked by agents, operators, or future UI surfaces.

## First Vertical Slice

Local ICP Project to Verified Local Deployment:

1. Create or import an ICP project.
2. Validate `icp.yaml`.
3. Start local network.
4. Run local deploy.
5. Read `.icp/cache/mappings/local.ids.json`.
6. Generate a proof record.

## Operator Gates

- Project intake gate
- Local deploy gate
- Proof record gate
- Promotion locked gate

## Future Surfaces

- Next.js operator console
- GitHub project import
- Google Drive spec import
- recipe registry
- sync plugin studio
- staging/mainnet promotion gate
- Motoko sovereign proof registry
- Julia benchmark/certification engine
