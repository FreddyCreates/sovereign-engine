# Nova ICP Forge

Nova ICP Forge is a local-first toolkit for wrapping `icp-cli` with Nova-native command policy, operator gates, canister discovery, and proof records.

The package is intentionally narrow in v0:

- scaffold or import one ICP project
- validate project shape
- run local-only `icp-cli` workflows
- discover local canister mappings
- generate proof records
- block mainnet, subnet, identity, cycles, token, snapshot restore, delete, and reinstall operations

## Quick Start

```bash
cd /workspace/nova-icp-forge
npm test
node bin/nova-icp-forge.js doctor
node bin/nova-icp-forge.js help
```

Dry-run local deploy:

```bash
node bin/nova-icp-forge.js deploy-local --project ./workspaces/projects/example
```

Real local execution:

```bash
node bin/nova-icp-forge.js deploy-local --project ./workspaces/projects/example --execute
```

Only use `--execute` for a local project you intend to build. v0 blocks connected-network authority.

## Engines

- `policy`: compiles approved intents into argv arrays.
- `runner`: executes argv with `shell: false`, sanitized env, output capture, timeout, and redaction.
- `workspace`: resolves and contains all paths under the Nova workspace.
- `gate`: evaluates project and deploy checks.
- `canister`: reads `.icp/cache/mappings/local.ids.json`.
- `proof`: writes append-only proof records.

## v0 Command Intents

- `version`
- `scaffold_project`
- `project_show`
- `network_start`
- `network_status`
- `network_stop`
- `build`
- `deploy_local`
- `sync`

## Promotion Law

Mainnet is not a v0 feature. The code must prove local-only behavior before staging/mainnet gates are introduced.
