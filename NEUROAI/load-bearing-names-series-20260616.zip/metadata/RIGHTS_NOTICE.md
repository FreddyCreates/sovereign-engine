# Rights Notice

Copyright (c) 2026 Alfredo Medina. All rights reserved unless otherwise licensed in the final Zenodo record or accompanying license file.

## Recommended Release Posture

- Confirm the exact license before public upload.
- Keep paper text and code license separate if needed.
- Use Zenodo DOI or related identifier as an archive record, not as a substitute for formal legal registration.
- Keep `hash_manifest.json` with the release bundle.
- Optional: pursue formal copyright registration through the appropriate legal route if stronger formal registration is desired.

## Not Legal Advice

This notice is a release-planning artifact, not legal advice and not a claim of legal filing.

