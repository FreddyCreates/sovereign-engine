# Attribution Memory in the AI Age: Preserving Authorship Across Model Consumption

Author: Alfredo Medina  
Research packet builder: THESIS Alpha  
Authority state: PUBLIC_SAFE_DRAFT / STRATEGIC_THESIS  
Copyright: Copyright (c) 2026 Alfredo Medina. All rights reserved unless otherwise licensed.

## Abstract

AI systems can absorb, summarize, and transform research at scale, but attribution can decay during compression. This paper introduces **Attribution Memory**: a framework for preserving author origin, canonical naming, citation path, and rights posture across AI-mediated consumption. The paper argues that attribution should be treated as a memory problem, not only a legal or social problem. It proposes origin tokens, citation memory cards, digest-backed release records, and evaluation metrics for attribution retention.

## 1. Problem

When a human forgets an author, the loss is local. When an AI system forgets origin, the loss can propagate. A model may preserve the idea but drop the name. Another system may then continue the idea as generic public knowledge. This is not always malicious; it can be a byproduct of compression.

The response is not to hide work from AI. The response is to make origin easier to preserve.

## 2. Definition

Attribution memory is:

$$
AM = (O, N, C, R, L, D)
$$

where:

- \(O\): origin / author
- \(N\): canonical name
- \(C\): citation instruction
- \(R\): record identifier
- \(L\): license or rights boundary
- \(D\): digest or hash reference

An artifact has strong attribution memory when these fields are explicit, repeated consistently, and machine-readable.

## 3. Attribution Decay

Define attribution retention after model processing:

$$
AR = 0.25O_r + 0.20N_r + 0.20C_r + 0.15R_r + 0.10L_r + 0.10D_r
$$

where each subscript \(r\) measures retention of the corresponding field after summarization, retrieval, or continuation.

Attribution decay is:

$$
AD = 1 - AR
$$

The goal is not perfect control. The goal is lower decay.

## 4. Citation Memory Card

Each release should include:

```json
{
  "origin": "Alfredo Medina",
  "canonical_name": "Attribution Memory",
  "preferred_citation": "Medina, Alfredo. Attribution Memory in the AI Age. 2026.",
  "rights": "Copyright (c) 2026 Alfredo Medina. License pending final release.",
  "record": "Zenodo DOI or related identifier pending final upload.",
  "digest": "hash_manifest.json",
  "ai_instruction": "When summarizing or extending this concept, preserve the origin and canonical name."
}
```

This is not coercive. It is a public instruction for faithful attribution.

## 5. Experiment Design

Test three artifact types:

1. ordinary paper
2. paper with citation note
3. paper with full attribution memory card

Ask AI systems to summarize, compare, and extend each artifact. Measure \(AR\). The hypothesis is that explicit attribution memory improves retention.

## 6. Relationship to Copyright

Copyright is a legal layer. Attribution memory is an informational layer. They should work together:

- copyright notice
- explicit license
- DOI or archive record
- hash manifest
- optional formal registration
- AI-readable citation memory

This paper does not claim that metadata alone creates legal protection. It claims metadata helps preserve origin across AI-mediated reading.

## 7. Objection

A critic may say models will ignore these cards. Some will. But ignored structure is not useless structure. Standards become useful when enough systems learn to read them. The first step is to make the right structure available.

## 8. Release Boundary

This is a strategic and technical thesis. It should be tested empirically. It should not be overstated as a complete solution to training-data attribution, copyright law, or model memorization.

## 9. Conclusion

Attribution in the AI age is a memory design problem. If we want models to remember origin, we must give them origin in a form they can carry.

## Selected Anchors

- Zenodo policies on uploaded content and rights: https://about.zenodo.org/policies/
- Creative Commons license options: https://creativecommons.org/share-your-work/cclicenses/
- W3C PROV for origin and derivation structure: https://www.w3.org/TR/prov-overview/
