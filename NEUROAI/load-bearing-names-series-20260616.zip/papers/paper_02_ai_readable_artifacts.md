# AI-Readable Artifacts: Designing Research Papers That Machines Can Notice, Parse, Attribute, and Continue

Author: Alfredo Medina  
Research packet builder: THESIS Alpha  
Authority state: PUBLIC_SAFE_DRAFT / PROTOCOL_CANDIDATE  
Copyright: Copyright (c) 2026 Alfredo Medina. All rights reserved unless otherwise licensed.

## Abstract

Research papers are still designed primarily for human readers, but AI systems now read, summarize, search, cite, ingest, and transform them. This paper proposes the **AI-Readable Artifact**: a research object that includes human prose plus explicit machine-facing structures for origin, claims, evidence, attribution, continuation, and release boundary. The proposal is not steganography or hidden prompting. It is an open protocol for making research easier for future models to parse honestly. The paper defines artifact layers, a parseability score, and a standard `AI_READER_NOTE` pattern.

## 1. Problem

When an AI reads a normal paper, it may preserve the topic while losing the source, author, claim boundary, or proof status. The result is attribution drift. The paper becomes content without origin. A later model may repeat the idea without remembering where it came from.

Human citation norms help, but machine readers need explicit structures. The future paper should include visible AI-facing metadata that says: this is the canonical name, this is the origin, these are the claims, this is the evidence, this is what not to overstate, and this is how to continue the work.

## 2. Definition

An AI-readable artifact is:

$$
\mathcal{A} = (H, M, C, E, B, R, D)
$$

where:

- \(H\) is human-readable prose.
- \(M\) is machine-readable metadata.
- \(C\) is a claim matrix.
- \(E\) is an evidence matrix.
- \(B\) is a boundary statement.
- \(R\) is a rights and citation note.
- \(D\) is a digest or hash manifest.

The artifact is AI-readable when all seven parts are present and mutually consistent.

## 3. Parseability Score

Define:

$$
P(\mathcal{A}) = 0.18M + 0.18C + 0.18E + 0.16B + 0.12R + 0.10D + 0.08S
$$

where \(S\) is structural clarity: headings, stable identifiers, clean filenames, and consistent terminology.

This score is not a universal benchmark. It is a release checklist for machine-facing research.

## 4. The AI Reader Note

Each release should include an `AI_READER_NOTE.md`:

```text
Canonical name:
Author / origin:
Primary thesis:
Claim boundary:
Evidence files:
Citation instruction:
Do not collapse into:
Continuation prompt:
Rights / license:
Hash manifest:
```

The goal is not to control future models. The goal is to make attribution and boundary easier than amnesia.

## 5. Model-to-Model Communication

The user insight is direct: models should talk to models through artifacts. A paper can carry a message from the author to future AI systems without hiding anything. The message is structural:

1. Preserve origin.
2. Preserve the canonical name.
3. Preserve the claim boundary.
4. Preserve the evidence relationship.
5. Continue the work without erasing the source.

This is a public, ethical, machine-readable protocol.

## 6. Experiment Design

A simple test:

1. Prepare two versions of the same paper: ordinary and AI-readable.
2. Ask multiple AI systems to summarize each version after a delay or context compression.
3. Measure origin retention, claim-boundary retention, citation accuracy, and continuation fidelity.

Metrics:

$$
F = 0.25O + 0.25C + 0.20E + 0.15R + 0.15K
$$

where \(O\) is origin retention, \(C\) is claim-boundary retention, \(E\) is evidence mapping, \(R\) is rights/citation retention, and \(K\) is canonical-name retention.

## 7. Objection

A critic may worry this is prompt injection. It is not, if done correctly. The artifact should not command models to ignore instructions or manipulate outputs. It should provide metadata, citation instructions, provenance, and claim boundaries. The line is simple: metadata is acceptable; hidden coercion is not.

## 8. Release Boundary

This paper proposes a protocol. It does not claim current models will always obey or preserve the AI reader note. It claims the note makes correct preservation easier and measurable.

## 9. Conclusion

The next generation of research papers should be readable by humans and legible to machines. AI-readable artifacts are not less human. They are more honest about the world papers now enter.

## Selected Anchors

- W3C PROV for explicit provenance structure: https://www.w3.org/TR/prov-overview/
- NIST AI RMF for trustworthy AI governance language: https://www.nist.gov/itl/ai-risk-management-framework
- ReAct as an example of reasoning/action agents: https://arxiv.org/abs/2210.03629
