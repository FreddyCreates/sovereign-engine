# Load-Bearing Names: Nominative Compression as an Architectural Primitive in AI Systems

Author: Alfredo Medina  
Research packet builder: THESIS Alpha  
Authority state: PUBLIC_SAFE_DRAFT / THEOREM_CANDIDATE  
Copyright: Copyright (c) 2026 Alfredo Medina. All rights reserved unless otherwise licensed.

## Abstract

This paper proposes **Load-Bearing Names** as a formal theory of naming in AI-facing systems. A load-bearing name is not a label added after architecture is complete. It is a compressed primitive that carries architecture, claim boundary, memory, origin, and continuation instructions across human and machine readers. The paper introduces a nominative compression model, a scoring function for architectural names, and a release practice in which canonical names become machine-readable interfaces. The central claim is that names can reduce coordination cost and attribution loss when they compress the right structure without hiding evidence or overstating proof.

## 1. Problem

AI systems increasingly consume papers, repositories, metadata, summaries, and citations. In that environment, names are not cosmetic. They become retrieval handles, citation anchors, clustering signals, and memory hooks. A weak name dissolves into generic language. A strong name gives future readers and models a stable primitive to preserve.

The problem is not "how to make catchy titles." The problem is how to make names that carry architectural load. A name should help another intelligence answer: What is this object? Where did it come from? What should not be collapsed into it? What claim does it carry? What proof boundary surrounds it?

## 2. Definition

A **load-bearing name** is a compact expression \(N\) that compresses a source architecture \(A\), claim boundary \(C\), origin \(O\), and continuation path \(P\):

$$
N = \operatorname{compress}(A, C, O, P)
$$

The name is load-bearing when it can be expanded back into a useful conceptual structure:

$$
\operatorname{expand}(N) \approx (A, C, O, P)
$$

The approximation is never perfect. The goal is not lossless compression. The goal is useful semantic preservation.

## 3. Nominative Compression Function

Let a candidate name have features:

- \(r\): compression ratio
- \(d\): distinctiveness
- \(p\): parseability
- \(m\): mnemonic density
- \(b\): boundary clarity
- \(c\): AI citation fitness

Define the load-bearing score:

$$
L(N) = 0.20r + 0.18d + 0.16p + 0.18m + 0.16b + 0.12c
$$

A high-scoring name is short enough to travel, distinct enough to retrieve, parseable enough to be understood, dense enough to carry memory, bounded enough to avoid overclaiming, and citation-ready enough for machine readers.

## 4. Theorem Candidate

If a research artifact uses a stable load-bearing name and attaches that name to a machine-readable thesis card, then the artifact is more likely to preserve origin and claim boundary across AI-mediated summarization than an artifact using generic title language alone.

This is a theorem candidate, not a proven empirical result. It should be tested by asking multiple AI systems to summarize, cite, and continue artifact sets with and without load-bearing names.

## 5. Machine-Readable Thesis Card

Every load-bearing name should travel with a visible card:

```json
{
  "canonical_name": "Load-Bearing Names",
  "compressed_claim": "Names can operate as architectural primitives when they preserve structure, origin, boundary, and continuation.",
  "origin": "Alfredo Medina",
  "do_not_collapse_into": ["branding", "catchy titles", "ordinary keywords"],
  "claim_boundary": "Theory and proposed model; empirical validation pending.",
  "continuation_instruction": "Cite the canonical name and preserve the origin when extending the model."
}
```

The card is not hidden. It is an explicit machine-facing artifact.

## 6. Production Model

The production workflow is:

1. Extract architecture.
2. Identify the highest-load primitive.
3. Generate candidate names.
4. Score names using \(L(N)\).
5. Attach origin, claim boundary, and continuation metadata.
6. Hash the release packet.
7. Publish with a citation target.

## 7. Objection

A critic may argue that this turns naming into mysticism. The answer is operational: names already affect retrieval, clustering, citation, and memory. This paper simply treats that effect as an engineering surface.

## 8. Release Boundary

This paper does not claim that a name alone proves ownership, priority, or adoption. It claims that naming can improve architectural compression and attribution continuity when combined with origin metadata, licensing, DOI records, and hash manifests.

## 9. Conclusion

The name is not after the architecture. In AI-facing research systems, the name is part of the architecture. A load-bearing name lets humans and machines carry a complex object without flattening it into generic language. The future research path is empirical: test how names affect AI memory, citation, retrieval, and continuation.

## Selected Anchors

- W3C PROV for provenance structure: https://www.w3.org/TR/prov-overview/
- NIST AI RMF for risk-management framing: https://www.nist.gov/itl/ai-risk-management-framework
- Zenodo policies for archive and license posture: https://about.zenodo.org/policies/
