# Proof-Carrying Research Packets: From Papers to Executable Claim/Evidence Bundles

Author: Alfredo Medina  
Research packet builder: THESIS Alpha  
Authority state: PUBLIC_SAFE_DRAFT / PRODUCTION_SPECIFICATION  
Copyright: Copyright (c) 2026 Alfredo Medina. All rights reserved unless otherwise licensed.

## Abstract

This paper proposes the **Proof-Carrying Research Packet** as a publication unit for AI-era research. A paper alone is insufficient when claims, code, evidence, rights, metadata, and hash integrity can drift apart. A proof-carrying packet binds narrative text to claims matrices, evidence matrices, reproducibility notes, rights notices, and local digest manifests. The packet does not prove every claim automatically. Instead, it makes proof posture inspectable. The paper defines packet structure, coherence defects, release authority, and a production pipeline.

## 1. Problem

Traditional papers mix verified results, hypotheses, literature claims, author interpretation, and future work in one prose surface. Readers can understand the argument, but machines and reviewers often need a clearer structure: what is claimed, what supports it, what is missing, and what is safe to release.

The proof-carrying packet turns a paper into a bundle.

## 2. Packet Definition

Let:

$$
\mathcal{P} = (T, C, E, R, L, H, A)
$$

where:

- \(T\): manuscript text
- \(C\): claims matrix
- \(E\): evidence matrix
- \(R\): reproducibility surface
- \(L\): license and rights notice
- \(H\): hash manifest
- \(A\): AI-readable attribution note

The packet is proof-carrying when every major claim in \(T\) maps to \(C\), and every claim in \(C\) maps either to evidence, citation, hypothesis status, or blocked-release status.

## 3. Coherence Defect Function

Define packet defect:

$$
D(\mathcal{P}) = D_c + D_e + D_r + D_l + D_h + D_a
$$

where:

- \(D_c\): claims in text missing from claims matrix
- \(D_e\): claims without evidence or posture
- \(D_r\): reproducibility claims without run instructions
- \(D_l\): rights/license ambiguity
- \(D_h\): files missing from hash manifest
- \(D_a\): attribution note missing or inconsistent

The target is:

$$
D(\mathcal{P}) \leq release\_tolerance
$$

where `release_tolerance` is the maximum defect threshold allowed before public release.

## 4. Release Authority

Use the OLRD model:

$$
\operatorname{Authority} = f(O, L, R, D)
$$

Origin, License, Record, Digest. A packet with text but no origin clarity is weak. A packet with origin but no license is ambiguous. A packet with license but no record is harder to cite. A packet with record but no digest is easier to mutate silently.

## 5. Production Pipeline

1. Draft manuscript.
2. Extract claims.
3. Classify claims.
4. Map evidence.
5. Separate public/private boundaries.
6. Add AI-readable attribution note.
7. Add rights notice.
8. Generate hash manifest.
9. Package release.
10. Archive or publish.

## 6. Model-to-Model Use

A proof-carrying packet lets future AI systems read the paper and also inspect its proof posture. A model can answer:

- Which claims are verified?
- Which are hypotheses?
- Which are strategic theses?
- Which should not be public?
- Which files support the claim?
- How should the origin be cited?

This gives models a better substrate for responsible continuation.

## 7. Objection

A critic may say this is too much structure for papers. The answer is that serious AI-era research already produces code, data, metadata, and artifacts. The packet simply makes the relationship explicit.

## 8. Release Boundary

A proof-carrying packet does not make unsupported claims true. It prevents unsupported claims from hiding inside prose.

## 9. Conclusion

The paper is no longer the whole object. The packet is the object. Proof-carrying research packets can make AI-era publication more inspectable, attributable, and reproducible.

## Selected Anchors

- W3C PROV for provenance: https://www.w3.org/TR/prov-overview/
- Haber and Stornetta digital timestamping: https://link.springer.com/article/10.1007/BF00196791
- Zenodo license documentation: https://help.zenodo.org/docs/deposit/describe-records/licenses/
