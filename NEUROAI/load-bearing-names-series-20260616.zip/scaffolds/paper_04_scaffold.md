# Scaffold: Attribution Memory in the AI Age

## Research Question

How can research artifacts preserve authorship across AI-mediated reading, summarization, and continuation?

## Core Model

`AM = (O, N, C, R, L, D)`

Origin, name, citation instruction, record, license, digest.

## Sections

1. Problem: attribution decay.
2. Definition: attribution memory.
3. Attribution retention and decay formulas.
4. Citation memory card.
5. Experiment design.
6. Copyright relationship.
7. Limits of metadata.

## Evidence Needed Later

- Multi-model attribution retention experiment
- License/citation retention study
- Comparison of ordinary vs card-bearing papers

