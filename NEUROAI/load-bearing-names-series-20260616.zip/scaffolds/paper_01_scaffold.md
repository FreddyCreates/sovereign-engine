# Scaffold: Load-Bearing Names

## Research Question

Can names operate as architectural primitives for AI-facing research systems?

## Core Model

`N = compress(A, C, O, P)`

Name = compression of architecture, claim boundary, origin, and continuation path.

## Sections

1. Problem: generic names disappear under AI compression.
2. Definition: load-bearing name.
3. Formula: load-bearing score.
4. Theorem candidate: names improve origin/boundary retention.
5. Machine-readable thesis card.
6. Production model.
7. Objections and release boundary.

## Evidence Needed Later

- AI summarization retention experiment
- Retrieval test across candidate names
- Citation persistence test

