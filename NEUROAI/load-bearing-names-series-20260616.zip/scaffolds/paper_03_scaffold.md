# Scaffold: Proof-Carrying Research Packets

## Research Question

Can publication units become claim/evidence bundles rather than prose-only papers?

## Core Model

`\mathcal{P} = (T, C, E, R, L, H, A)`

Text, claims, evidence, reproducibility, license, hash, attribution.

## Sections

1. Problem: prose hides proof posture.
2. Packet definition.
3. Coherence defect function.
4. OLRD release authority.
5. Production pipeline.
6. Model-to-model use.
7. Structural overhead objection.

## Evidence Needed Later

- Packet linter implementation
- Review-time comparison study
- Claim/evidence extraction benchmark

