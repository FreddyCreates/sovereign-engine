# Scaffold: AI-Readable Artifacts

## Research Question

How should public research artifacts be structured so AI systems can parse, attribute, and continue them without erasing origin?

## Core Model

`\mathcal{A} = (H, M, C, E, B, R, D)`

Human prose, metadata, claims, evidence, boundary, rights, digest.

## Sections

1. Problem: attribution drift during AI reading.
2. Definition: AI-readable artifact.
3. Parseability score.
4. AI reader note.
5. Model-to-model communication.
6. Experiment design.
7. Prompt-injection objection.

## Evidence Needed Later

- Cross-model summary retention tests
- AI reader note compliance analysis
- Prompt-injection safety review

