# Scaffold: The Name Is the Interface

## Research Question

Can the name serve as the interface between architecture, proof packet, archive record, and future model memory?

## Core Model

`\mathcal{L} = A -> N -> P -> R -> M -> A'`

Architecture to name to packet to record to model memory to continuation.

## Sections

1. Central claim.
2. Name-interface loop.
3. Interface quality formula.
4. Series integration.
5. Why it matters.
6. AI-readable continuation.
7. Door-handle objection.

## Evidence Needed Later

- End-to-end continuation tests
- Model memory preservation tests
- Archive metadata impact study

