# Load-Bearing Names Series

Series ID: `MEDINA-LBN-SERIES-20260616`

Authority state: `PUBLIC_SAFE_DRAFT / CLAIM_HARDENED`

Author / origin: Alfredo Medina, with THESIS Alpha as research packet builder.

## Series Thesis

Names can act as load-bearing compression primitives in AI-facing research systems. A strong name is not decoration. It compresses architecture, claim boundary, memory hook, citation surface, and continuation instruction into a compact object that humans and AIs can carry forward.

## Shared Release Model: OLRD

The standing operating posture is formalized as the **Origin-Licensed Release Digest Model** (`OLRD`):

1. **Origin** — author, creator, source lineage, and canonical name.
2. **License** — explicit usage boundary and rights posture.
3. **Record** — DOI, archive record, citation target, or registry reference.
4. **Digest** — hash manifest, file integrity, and optional notarization/registration path.

Formula:

```text
release_authority = f(origin_clarity, license_clarity, record_stability, digest_integrity)
```

No serious release should leave Medina without these four fields.

## Papers

1. `paper_01_load_bearing_names.md`
2. `paper_02_ai_readable_artifacts.md`
3. `paper_03_proof_carrying_research_packets.md`
4. `paper_04_attribution_memory_ai_age.md`
5. `paper_05_name_is_interface.md`

Each paper includes:

- full manuscript
- scaffold
- machine-readable thesis card
- release boundary
- model/formula layer
- rights notice

## Rights Boundary

These drafts include a copyright notice for Alfredo Medina and a license-selection placeholder. This packet does not itself perform legal filing or copyright-office registration.

