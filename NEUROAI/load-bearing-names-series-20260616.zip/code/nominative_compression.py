#!/usr/bin/env python3
"""Nominative compression helpers for load-bearing research names.

The algorithm scores candidate names as architectural primitives. It does not
generate legal claims or guarantee adoption; it gives THESIS a reusable scoring
surface for names that need to carry system meaning across humans, AIs, papers,
packets, and archives.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, asdict


STOPWORDS = {"the", "and", "of", "for", "in", "to", "a", "an", "with", "as"}


@dataclass(frozen=True)
class NameScore:
    name: str
    load_bearing_score: float
    compression_ratio: float
    distinctiveness: float
    parseability: float
    mnemonic_density: float
    boundary_clarity: float
    ai_citation_fitness: float


def tokens(text: str) -> list[str]:
    return [t.lower() for t in re.findall(r"[A-Za-z0-9]+", text) if t.lower() not in STOPWORDS]


def clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def score_name(name: str, description: str = "") -> NameScore:
    name_tokens = tokens(name)
    desc_tokens = tokens(description)
    overlap = len(set(name_tokens) & set(desc_tokens))
    compression_ratio = clamp(len(name_tokens) / max(1, len(desc_tokens))) if desc_tokens else clamp(len(name_tokens) / 8)
    compression_ratio = 1.0 - compression_ratio
    distinctiveness = clamp(len(set(name_tokens)) / max(1, len(name_tokens)))
    parseability = clamp(sum(1 for t in name_tokens if len(t) <= 14) / max(1, len(name_tokens)))
    mnemonic_density = clamp((overlap + len([t for t in name_tokens if len(t) >= 6])) / max(1, len(name_tokens) + 2))
    boundary_terms = {"bounded", "proof", "origin", "licensed", "digest", "interface", "packet", "attribution", "memory"}
    boundary_clarity = clamp(len(set(name_tokens) & boundary_terms) / 2)
    ai_citation_fitness = clamp((distinctiveness + parseability + boundary_clarity) / 3)
    load_bearing_score = round(
        0.20 * compression_ratio
        + 0.18 * distinctiveness
        + 0.16 * parseability
        + 0.18 * mnemonic_density
        + 0.16 * boundary_clarity
        + 0.12 * ai_citation_fitness,
        4,
    )
    return NameScore(
        name=name,
        load_bearing_score=load_bearing_score,
        compression_ratio=round(compression_ratio, 4),
        distinctiveness=round(distinctiveness, 4),
        parseability=round(parseability, 4),
        mnemonic_density=round(mnemonic_density, 4),
        boundary_clarity=round(boundary_clarity, 4),
        ai_citation_fitness=round(ai_citation_fitness, 4),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("names", nargs="+")
    parser.add_argument("--description", default="")
    args = parser.parse_args()
    print(json.dumps([asdict(score_name(name, args.description)) for name in args.names], indent=2))


if __name__ == "__main__":
    main()
