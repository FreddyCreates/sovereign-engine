# Reproducibility Plan

## Current Evidence State

The supplied packet contains a 60-row CSV experiment with 30 baseline and 30 brain-powered runs for a single threat-memory-navigation scenario. It also contains controlled simulation reports and UI evidence. The dataset supports internal comparison claims for that scenario, but it does not yet provide a complete reproduction package.

## Required Reproduction Contents

- Scenario definition for `threat-memory-navigation`.
- Source code or executable harness used to generate the CSV.
- Configuration for baseline and brain-powered conditions.
- Metric definitions for task success, route efficiency, adaptation, recovery, coherence, emergence, novelty, self-state coherence, latency, compute proxy, artifact probability, and saturation controls.
- Seed list and randomization method.
- Raw logs for all runs.
- Summary-statistics script.
- Ablation configurations.
- Known limitations and blocked claim list.

## Ablations

- Remove rotational governance.
- Remove memory routing.
- Remove embodied/autonomic variables.
- Remove verification pressure.
- Remove role specialization.
- Alter saturation controls.
- Add additional baselines beyond the current baseline condition.

## Statistical Checks

- Report mean, standard deviation, min, max, and confidence intervals.
- Use effect sizes, not only mean differences.
- Check bounded or degenerate metrics carefully, especially metrics with all-zero or all-one conditions.
- Replicate across multiple scenarios before making broader architecture claims.

## Release Gate

Public release should wait until reproduction scripts, metric definitions, and artifact hashes are bundled. Until then, claims should remain internal research or public-safe preliminary framing.
