# Theorem Map

## Core Thesis

Persistent cognitive organisms require architecture, not only intelligence.

## Candidate Theorem

If a cognitive system is composed of role-specialized organs, durable memory, governed rotation of attention/action, embodied constraint, and proof-bounded reporting, then it can be evaluated as persistent cognitive infrastructure rather than as a temporary prompt-response agent.

## Mechanism Stack

1. **Role specialization**
   - Memory, reasoning, verification, governance, routing, execution, and sensing become bounded organs.
2. **Rotational governance**
   - Attention, state access, verification, and action circulate by role and priority instead of activating everywhere at once.
3. **Embodied constraint**
   - Simulation variables impose internal regulation, recovery pressure, and task-state coupling.
4. **Continuity**
   - Persistent memory and durable runtime identity prevent the system from restarting from zero at every prompt.
5. **Proof pressure**
   - Reports must preserve weak-effect verdicts, saturation warnings, metric boundaries, and public/private release gates.

## Evidence Connection

- The rotating-cloud-engine draft supports the architecture thesis.
- The connectome session report supports the existence of structured embodied simulation telemetry, with saturation warnings.
- The Triaxion-47 report supports validity-aware controlled lab reporting, with a weak-effect boundary.
- The CSV experiment supports an internal simulation result: brain-powered runs strongly outperformed baseline runs in the recorded threat-memory-navigation scenario.

## Strongest Objection

The current evidence is simulation-internal. It does not yet prove generalization, biological validity, production deployment, or consciousness.

## Next Proof Move

Attach simulator code, freeze metric definitions, run ablations, add statistical tests, and preserve raw logs in a reproducibility packet with hashes.
