# NeuroAI as Big Science

## A CERN-Scale Research Program for Natural and Artificial Intelligence

Series: NeuroAI CERN-Level Preprint Series, Paper 1  
Authority state: `CLAIM_HARDENED / PUBLIC_SAFE_DRAFT`  
Primary claim class: `C4 strategic thesis` and `C8 protocol candidate`

## Abstract

NeuroAI is often described as a bidirectional exchange between neuroscience and artificial intelligence. That description is correct but too small for the scale of the problem. This paper argues that NeuroAI should be organized as a big-science program: shared benchmarks, standard experimental tasks, open model registries, interoperable neural datasets, embodied evaluation arenas, and governance rules for distinguishing biological plausibility from engineering performance. The argument is inspired by calls for centralized NeuroAI infrastructure and embodied evaluation in the recent literature, including the proposal that NeuroAI may require a coordinated effort comparable in spirit to large scientific instruments rather than isolated laboratory projects [1]. The paper does not claim that such an institution exists today. It proposes a program architecture for making NeuroAI falsifiable, cumulative, and worthy of the word “science.”

## 1. Central Thesis

NeuroAI needs a big-science substrate: not only models and papers, but shared instruments, benchmark regimes, data standards, reproducibility pipelines, and adversarial review loops. A field that claims to connect artificial agents with natural intelligence cannot mature if every lab uses incompatible tasks, private preprocessing, noncomparable neural datasets, and informal definitions of “brain-like.”

The CERN analogy is not about particle physics equipment. It is about epistemic scale. CERN works because major claims are routed through shared instruments, calibrated protocols, community scrutiny, durable records, and international collaboration. A serious NeuroAI program needs the same posture: common infrastructure for testing models against behavior, neural recordings, embodiment, learning efficiency, energy limits, developmental constraints, and robustness under distribution shift.

## 2. Why NeuroAI Requires Infrastructure

The 2023 NeuroAI position paper argues that neuroscience has historically influenced AI and that next-generation AI may require deeper integration with biological intelligence [1]. It also points toward embodied evaluation: agents should not merely classify static data but interact with sensorimotor environments. This matters because many current AI benchmarks measure frozen task competence rather than adaptive organism-like intelligence.

A big-science NeuroAI program would coordinate four layers:

1. **Experimental substrate**: standardized neural, behavioral, and embodied tasks.
2. **Model substrate**: open model submission interfaces, architecture metadata, and training-regime records.
3. **Evaluation substrate**: benchmark suites that compare not only task performance but neural alignment, learning regime, sample efficiency, robustness, and energy cost.
4. **Governance substrate**: claim classes that prevent a model from being called brain-like merely because it performs well on one benchmark.

Brain-Score is already a partial model of this direction: it offers a platform for comparing artificial models to neural and behavioral measurements and maintaining a leaderboard across benchmarks [3]. NeuralBench extends the same infrastructure logic to brain-recording models, reporting a unified EEG benchmark with 36 tasks, 14 architectures, and 94 datasets [2]. These systems show that NeuroAI is already moving toward shared instruments. The missing step is to treat such infrastructure as the spine of the field rather than as optional tooling.

## 3. The Four Pillars of a CERN-Level NeuroAI Program

### 3.1 Common Measurement

A mature NeuroAI field requires repeated measurement against common targets. Task accuracy alone is insufficient. A model should be evaluated across behavior, neural predictivity, intervention sensitivity, learning trajectory, and ecological transfer. A high-performing black-box classifier may be useful engineering, but it is not automatically a mechanistic hypothesis about the brain.

### 3.2 Embodied Evaluation

The embodied Turing-test idea reframes intelligence as situated interaction rather than disembodied response generation [1]. NeuroAI should measure how agents perceive, act, update, explore, and stabilize behavior over time. This requires environments where models must learn from sensorimotor loops rather than static corpora.

### 3.3 Cross-Scale Alignment

NeuroAI spans spikes, circuits, systems, behavior, and language-level cognition. No single scale should dominate. The benchmark program should explicitly report which scale a model addresses. A model may be useful for neural decoding without being a theory of cognition; another may predict behavior without resembling neural dynamics.

### 3.4 Claim Governance

The field needs controlled language. “Brain-inspired,” “brain-aligned,” “biologically plausible,” “neural predictive,” and “cognitive model” should not be used interchangeably. Each term should imply an evidence standard. THESIS-style packet governance can help by classifying claims as verified benchmark results, supported internal results, hypotheses, strategic theses, or private/internal implementation notes.

## 4. Proposed Institutional Architecture

A CERN-level NeuroAI center should maintain:

- a model registry with training, data, compute, architecture, and license metadata;
- neural and behavioral benchmark suites with versioned tasks;
- multimodal data access layers for EEG, MEG, fMRI, spikes, behavior, and embodied simulation;
- blind-evaluation pipelines;
- reproducibility containers;
- failure-case archives;
- safety and ethics review for neural data use;
- public/private boundaries for sensitive datasets and models;
- publication packets that include claims matrices and evidence matrices.

This architecture is not meant to replace individual laboratories. It should let them contribute modules to a shared measurement system.

## 5. Claim Boundary

This paper makes a strategic and institutional thesis: NeuroAI should be organized as a big-science program. It does not prove that such a program will solve general intelligence. It does not claim that biological alignment guarantees safety. It does not claim that existing benchmarks are sufficient. It argues that without shared infrastructure, the field will continue to produce isolated partial results that are difficult to compare.

## 6. Strongest Objection

The strongest objection is that big-science infrastructure can freeze a young field too early. If standards are imposed prematurely, they may favor today's models and tasks while excluding disruptive approaches. The answer is modular governance: benchmark suites should be versioned, extensible, and adversarially revised. CERN-level does not mean bureaucratic rigidity. It means durable shared instruments whose assumptions can be audited.

## 7. Conclusion

NeuroAI will not become rigorous by scaling rhetoric. It becomes rigorous by scaling measurement. A CERN-level NeuroAI program would give the field shared instruments for testing whether models are merely performant, behaviorally aligned, neurally predictive, biologically plausible, or genuinely explanatory. That distinction is the beginning of scientific seriousness.


## References

1. Zador et al., “Catalyzing next-generation Artificial Intelligence through NeuroAI,” *Nature Communications* (2023). https://www.nature.com/articles/s41467-023-37180-x
2. Banville et al., “NeuralBench: A Unifying Framework to Benchmark NeuroAI Models,” arXiv:2605.08495 (2026). https://arxiv.org/abs/2605.08495
3. Brain-Score, “Integrative Benchmarks | Models at Scale.” https://www.brain-score.org/
4. Walsh et al., “The empirical status of predictive coding and active inference,” *Neuroscience & Biobehavioral Reviews* (2024). https://pubmed.ncbi.nlm.nih.gov/38030100/
5. Asabuki and Clopath, “Taming the chaos gently: a predictive alignment learning rule in recurrent neural networks,” *Nature Communications* (2025). https://www.nature.com/articles/s41467-025-61309-9
6. Hasson, Nastase, and Goldstein, “Direct Fit to Nature,” *Neuron* (2020). https://www.sciencedirect.com/science/article/pii/S089662731931044X
7. NIH BRAIN NeuroAI Workshop final program book (2024). https://braininitiative.nih.gov/sites/default/files/documents/2024%20NIH%20BRAIN%20NeuroAI%20Workshop%20Final%20Program%20Book_508c%201.pdf
8. NIH BRAIN Research Roadmap Innovation Domains (2025). https://www.braininitiative.nih.gov/sites/default/files/2025-11/BRAIN%20Research%20Roadmap%20Innovation%20Domains_508c.pdf

