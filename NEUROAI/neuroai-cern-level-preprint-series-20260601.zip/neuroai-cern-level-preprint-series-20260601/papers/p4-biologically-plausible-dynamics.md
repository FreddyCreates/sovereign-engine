# Biologically Plausible Dynamics for NeuroAI

## Recurrent Learning, Plasticity, and the Limits of Transformer-Centric Intelligence

Series: NeuroAI CERN-Level Preprint Series, Paper 4  
Authority state: `CLAIM_HARDENED / PUBLIC_SAFE_DRAFT`  
Primary claim class: `C3 hypothesis` and `C9 theorem candidate`

## Abstract

Contemporary AI is dominated by large-scale feedforward-inference systems trained by gradient methods over vast data. Biological intelligence, by contrast, is recurrent, embodied, energy-constrained, plastic, developmental, and continuously active. This paper argues that NeuroAI should treat dynamical learning as a first-class research axis: recurrent networks, predictive plasticity, spiking systems, neuromorphic substrates, and online adaptation. Recent predictive-alignment work shows one possible direction: a biologically motivated learning rule that trains recurrent networks by shaping chaotic dynamics through prediction [5]. The paper does not claim that this method solves NeuroAI. It uses the example to frame a broader research program for learning systems whose dynamics, not only weights, are the computational substrate.

## 1. Central Thesis

NeuroAI should not reduce brain inspiration to architecture motifs. The deeper substrate is dynamics: ongoing activity, recurrent feedback, plastic adaptation, memory over time, and interaction with body and environment.

## 2. Why Dynamics Matter

Brains are not static classifiers. They maintain activity, stabilize perception, generate action, regulate internal state, and learn under biological constraints. Recurrent neural networks have long offered one mathematical language for temporal processing, but many training methods rely on mechanisms that are difficult to interpret biologically. Predictive alignment work in 2025 proposed a learning framework in which recurrent networks learn patterned activities by aligning recurrent prediction with chaotic dynamics [5]. The result matters less as a final answer than as evidence of a research direction: biologically motivated learning rules can be tested as computational tools.

## 3. Direct Fit and the Biological Challenge

The “Direct Fit to Nature” perspective argues that over-parameterized artificial networks challenge older assumptions in psychology and neuroscience by showing the power of direct optimization over large datasets [6]. NeuroAI should take this seriously. Biological plausibility should not be used to dismiss high-performing artificial systems. But direct-fit performance also does not settle questions of embodiment, data efficiency, energy, developmental learning, or neural mechanism.

The right stance is comparative: direct-fit models, recurrent dynamical models, predictive world models, and neuromorphic systems should compete across typed evidence surfaces.

## 4. A Dynamical NeuroAI Research Program

A dynamical NeuroAI program should study:

1. **Recurrent state**: how models maintain context and stabilize behavior over time.
2. **Local plasticity**: how learning can occur without full global backpropagation through every process.
3. **Spiking and event-based computation**: how timing, sparsity, and energy constraints shape intelligence.
4. **Embodied feedback**: how action changes the data distribution the model receives.
5. **Developmental curricula**: how models acquire structure over staged experience rather than static pretraining.
6. **Failure dynamics**: how systems destabilize, hallucinate, perseverate, or recover.

## 5. Falsifiable Tests

Dynamical NeuroAI should be evaluated by tests that static benchmarks miss:

- robustness under delayed feedback;
- adaptation after lesion-like perturbation;
- recovery from distribution shift;
- memory retention under continual learning;
- energy-normalized performance;
- neural trajectory alignment;
- behavioral stability over long closed-loop episodes.

These tests make dynamics measurable rather than decorative.

## 6. Claim Boundary

This paper does not claim that recurrent, spiking, or biologically plausible methods are categorically superior to transformers or direct-fit systems. It claims that a NeuroAI science that ignores dynamics will miss core properties of biological intelligence. Superiority claims require benchmark evidence.

## 7. Strongest Objection

The strongest objection is pragmatic: transformer-style systems work, while biologically plausible learning often lags in scale and performance. The answer is not to deny current AI success. The answer is to ask what current systems still fail to do: continual adaptation, physical grounding, low-energy learning, robust action, and interpretable neural correspondence. Dynamical NeuroAI should target those gaps.

## 8. Conclusion

The future of NeuroAI should not be a contest between brain romance and engineering realism. It should be a measurement program where dynamical models, direct-fit systems, predictive agents, and benchmark-driven foundation models are compared under shared evidence rules. Biological plausibility earns its place when it produces testable advantages, mechanistic insight, or new capabilities under constraints that matter.


## References

1. Zador et al., “Catalyzing next-generation Artificial Intelligence through NeuroAI,” *Nature Communications* (2023). https://www.nature.com/articles/s41467-023-37180-x
2. Banville et al., “NeuralBench: A Unifying Framework to Benchmark NeuroAI Models,” arXiv:2605.08495 (2026). https://arxiv.org/abs/2605.08495
3. Brain-Score, “Integrative Benchmarks | Models at Scale.” https://www.brain-score.org/
4. Walsh et al., “The empirical status of predictive coding and active inference,” *Neuroscience & Biobehavioral Reviews* (2024). https://pubmed.ncbi.nlm.nih.gov/38030100/
5. Asabuki and Clopath, “Taming the chaos gently: a predictive alignment learning rule in recurrent neural networks,” *Nature Communications* (2025). https://www.nature.com/articles/s41467-025-61309-9
6. Hasson, Nastase, and Goldstein, “Direct Fit to Nature,” *Neuron* (2020). https://www.sciencedirect.com/science/article/pii/S089662731931044X
7. NIH BRAIN NeuroAI Workshop final program book (2024). https://braininitiative.nih.gov/sites/default/files/documents/2024%20NIH%20BRAIN%20NeuroAI%20Workshop%20Final%20Program%20Book_508c%201.pdf
8. NIH BRAIN Research Roadmap Innovation Domains (2025). https://www.braininitiative.nih.gov/sites/default/files/2025-11/BRAIN%20Research%20Roadmap%20Innovation%20Domains_508c.pdf

