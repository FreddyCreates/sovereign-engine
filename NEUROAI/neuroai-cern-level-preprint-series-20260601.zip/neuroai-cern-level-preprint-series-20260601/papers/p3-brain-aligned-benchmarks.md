# Brain-Aligned Benchmarks for NeuroAI

## Measurement, Neural Data, and the Discipline of Model Comparison

Series: NeuroAI CERN-Level Preprint Series, Paper 3  
Authority state: `CLAIM_HARDENED / PUBLIC_SAFE_DRAFT`  
Primary claim class: `C10 public-safe educational claim` and `C8 protocol candidate`

## Abstract

NeuroAI cannot advance on architectural imagination alone. It requires benchmark systems that measure how artificial models relate to neural activity, behavior, clinical signals, and task performance across datasets. This paper argues for a benchmark-first NeuroAI discipline built around versioned tasks, open model submissions, modality-aware evaluation, and explicit limits on what a benchmark score means. Brain-Score demonstrates the value of comparing models to neural and behavioral data [3]. NeuralBench extends the benchmark logic to brain activity models with a 2026 EEG-focused release spanning 36 tasks, 14 architectures, and 94 datasets [2]. These efforts show that NeuroAI is becoming a measurement science. The next step is to make benchmark interpretation as rigorous as benchmark construction.

## 1. Central Thesis

A NeuroAI model should not be called “brain-like” without specifying the benchmark, modality, task family, neural target, behavioral target, and comparison baseline. Benchmark scores must become typed claims, not social proof.

## 2. The Benchmark Problem

AI benchmarks often compress performance into a leaderboard. Neuroscience benchmarks are harder. A model can match neural data in one region but fail behaviorally. It can classify EEG tasks while learning features that do not generalize across subjects. It can predict fMRI responses but fail intervention tests. It can match human errors in one domain while relying on non-human shortcuts.

Brain-Score addresses part of this problem by evaluating models against neural and behavioral measurements and providing a unified comparison platform [3]. NeuralBench addresses another part by standardizing evaluation across many EEG tasks and datasets [2]. Together they suggest a new benchmark discipline: NeuroAI models should be scored against multiple evidence surfaces, not one aggregate trophy.

## 3. Typed Benchmark Claims

This paper proposes five typed benchmark claims:

1. **Task-performance claim**: the model performs well on a defined task.
2. **Neural-predictivity claim**: the model predicts neural measurements under a specified mapping.
3. **Behavioral-alignment claim**: the model matches behavioral patterns or errors.
4. **Generalization claim**: the model transfers across subjects, datasets, domains, or interventions.
5. **Mechanistic claim**: the model's internal variables correspond to plausible causal mechanisms.

Only the fifth claim approaches explanation. The first four can be valuable without being mechanistic.

## 4. NeuralBench and the EEG Generalization Challenge

NeuralBench reports a unified framework for benchmarking AI models of brain activity and introduces an EEG v1.0 release with 36 tasks, 14 architectures, and 94 datasets [2]. Its abstract notes that current foundation models only marginally outperform task-specific models and that tasks such as cognitive decoding and clinical prediction remain challenging [2]. This is exactly the kind of result a mature field needs: not hype, but calibrated difficulty.

The lesson is that foundation-scale methods do not automatically solve neural data. Neural recordings are noisy, heterogeneous, subject-specific, task-dependent, and often limited by acquisition constraints. NeuroAI benchmarks should therefore report not only average performance but robustness across subjects, acquisition devices, preprocessing pipelines, and clinical contexts.

## 5. Benchmark Governance

A CERN-level benchmark program should include:

- versioned datasets and task definitions;
- public model cards with architecture, training, and preprocessing details;
- blind test sets;
- modality-specific metrics for EEG, MEG, fMRI, spikes, and behavior;
- cross-subject and cross-dataset transfer tests;
- negative controls and shortcut audits;
- confidence intervals and uncertainty reporting;
- ethical controls for neural data privacy.

A benchmark that lacks governance can become an optimization target rather than a scientific instrument.

## 6. Claim Boundary

Benchmark success is not equivalent to biological explanation. A model may be useful for decoding or prediction without being a mechanistic account of the brain. This paper claims that benchmark infrastructure is necessary for NeuroAI rigor, not that existing benchmarks are sufficient or final.

## 7. Strongest Objection

The strongest objection is that benchmarks can narrow the field by rewarding what is easy to measure. The answer is plural evaluation: benchmarks should include open-ended tasks, adversarial datasets, intervention tests, and challenge tracks that reward failure discovery as well as performance.

## 8. Conclusion

NeuroAI needs benchmarks that behave like scientific instruments. Brain-Score and NeuralBench show two important directions: neural/behavioral model comparison and large-scale brain-recording evaluation. The next challenge is interpretation governance: every score must say what it proves, what it does not prove, and what evidence is still missing.


## References

1. Zador et al., “Catalyzing next-generation Artificial Intelligence through NeuroAI,” *Nature Communications* (2023). https://www.nature.com/articles/s41467-023-37180-x
2. Banville et al., “NeuralBench: A Unifying Framework to Benchmark NeuroAI Models,” arXiv:2605.08495 (2026). https://arxiv.org/abs/2605.08495
3. Brain-Score, “Integrative Benchmarks | Models at Scale.” https://www.brain-score.org/
4. Walsh et al., “The empirical status of predictive coding and active inference,” *Neuroscience & Biobehavioral Reviews* (2024). https://pubmed.ncbi.nlm.nih.gov/38030100/
5. Asabuki and Clopath, “Taming the chaos gently: a predictive alignment learning rule in recurrent neural networks,” *Nature Communications* (2025). https://www.nature.com/articles/s41467-025-61309-9
6. Hasson, Nastase, and Goldstein, “Direct Fit to Nature,” *Neuron* (2020). https://www.sciencedirect.com/science/article/pii/S089662731931044X
7. NIH BRAIN NeuroAI Workshop final program book (2024). https://braininitiative.nih.gov/sites/default/files/documents/2024%20NIH%20BRAIN%20NeuroAI%20Workshop%20Final%20Program%20Book_508c%201.pdf
8. NIH BRAIN Research Roadmap Innovation Domains (2025). https://www.braininitiative.nih.gov/sites/default/files/2025-11/BRAIN%20Research%20Roadmap%20Innovation%20Domains_508c.pdf

