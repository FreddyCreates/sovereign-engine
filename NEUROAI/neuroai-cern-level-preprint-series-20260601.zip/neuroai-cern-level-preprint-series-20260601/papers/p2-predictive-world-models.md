# Predictive World Models for NeuroAI

## From Predictive Coding and Active Inference to Closed-Loop Artificial Agents

Series: NeuroAI CERN-Level Preprint Series, Paper 2  
Authority state: `CLAIM_HARDENED / PUBLIC_SAFE_DRAFT`  
Primary claim class: `C9 theorem candidate` and `C3 hypothesis`

## Abstract

Predictive coding and active inference offer a powerful language for NeuroAI: intelligence as the maintenance and revision of generative world models under uncertainty. Yet the empirical status of these theories is uneven, and their translation into artificial agents is often overstated. This paper proposes a bounded NeuroAI thesis: predictive world modeling should be treated as an organizing research program for closed-loop agents, not as a settled proof of brain computation or a guaranteed path to artificial general intelligence. The paper defines a layered architecture for predictive agents, maps the claim boundary between neuroscience and engineering, and proposes falsifiable tests for evaluating whether predictive models improve robustness, embodiment, and sample efficiency.

## 1. Central Thesis

NeuroAI should treat prediction not as a slogan but as an experimental contract: a model must specify what is predicted, at what temporal scale, by which latent variables, through which update rule, under which action policy, and against what alternative model.

Predictive coding and active inference are attractive because they connect perception, action, uncertainty, and learning. Reviews of the empirical status of predictive coding and active inference emphasize both their reach and the need for formal comparison against alternative models [4]. A serious NeuroAI program should therefore use predictive frameworks to generate experiments, not to prematurely close debate.

## 2. A Layered Predictive Architecture

A closed-loop NeuroAI system can be decomposed into five layers:

1. **Sensory prediction**: the system predicts incoming observations and tracks prediction errors.
2. **Latent-state inference**: the system estimates hidden causes of sensory input.
3. **Temporal world modeling**: the system predicts transitions, sequences, and affordances.
4. **Action selection**: the system chooses actions expected to reduce uncertainty, satisfy goals, or improve model evidence.
5. **Self-calibration**: the system updates confidence, precision, and uncertainty estimates.

The NeuroAI claim is not that every brain operation follows exactly this structure. The claim is that this structure gives AI researchers a testable framework for agents that must learn and act under uncertainty.

## 3. Prediction Is Not Enough

Modern AI systems already use prediction extensively: language models predict tokens, video models predict frames, world models predict state transitions. But prediction alone does not make a system brain-like. A predictive NeuroAI agent must be evaluated by stronger criteria:

- Does prediction improve embodied action?
- Does the model generalize under intervention?
- Does uncertainty guide exploration?
- Does the system learn from small data in structured environments?
- Do internal states align with neural or behavioral measurements?
- Does the model fail in ways that resemble or illuminate biological failure modes?

Without these tests, “predictive” becomes a loose metaphor.

## 4. Active Inference as Engineering Hypothesis

Active inference is often framed as perception and action under a generative model. For engineering purposes, this suggests agents that plan by modeling the sensory consequences of action. That is promising, but the claim should remain bounded. Active inference models may explain some behavioral data, but empirical validation often requires formal comparison to non-Bayesian, reinforcement-learning, or model-free alternatives [4].

For NeuroAI, active inference should be treated as an engineering hypothesis: a route for building agents that integrate perception, uncertainty, and action. It becomes a biological claim only when model variables, update dynamics, and behavior are mapped to neural evidence.

## 5. Falsifiable Predictions

A CERN-level NeuroAI program should turn predictive world modeling into tests:

1. **Intervention test**: perturb latent state estimates and measure behavioral and neural changes.
2. **Uncertainty test**: manipulate observation noise and test whether precision estimates adjust behavior.
3. **Transfer test**: train in one environment and test structured generalization in another.
4. **Energy/sample test**: compare data and compute efficiency against non-predictive baselines.
5. **Neural-alignment test**: compare model state trajectories to neural recordings across tasks.

The key is comparison. A predictive model earns status by beating plausible alternatives on a defined evidence surface.

## 6. Claim Boundary

This paper does not claim that predictive coding or active inference is proven as a universal theory of brain function. It claims that predictive world modeling is a high-value research program for NeuroAI when paired with falsifiable tests, explicit baselines, and closed-loop tasks.

## 7. Strongest Objection

The strongest objection is that predictive processing can become unfalsifiably broad: any intelligent behavior can be retroactively described as prediction. The answer is operational specificity. The model must specify representational variables, prediction targets, error signals, update rules, and counterfactual baselines before evaluation.

## 8. Conclusion

Predictive world modeling is one of NeuroAI's deepest bridges between brains and machines. But the bridge only holds if its claims are bounded. The field should promote predictive coding and active inference as engines of experiment design, closed-loop architecture, and falsifiable modeling, not as rhetorical proof that intelligence has already been explained.


## References

1. Zador et al., “Catalyzing next-generation Artificial Intelligence through NeuroAI,” *Nature Communications* (2023). https://www.nature.com/articles/s41467-023-37180-x
2. Banville et al., “NeuralBench: A Unifying Framework to Benchmark NeuroAI Models,” arXiv:2605.08495 (2026). https://arxiv.org/abs/2605.08495
3. Brain-Score, “Integrative Benchmarks | Models at Scale.” https://www.brain-score.org/
4. Walsh et al., “The empirical status of predictive coding and active inference,” *Neuroscience & Biobehavioral Reviews* (2024). https://pubmed.ncbi.nlm.nih.gov/38030100/
5. Asabuki and Clopath, “Taming the chaos gently: a predictive alignment learning rule in recurrent neural networks,” *Nature Communications* (2025). https://www.nature.com/articles/s41467-025-61309-9
6. Hasson, Nastase, and Goldstein, “Direct Fit to Nature,” *Neuron* (2020). https://www.sciencedirect.com/science/article/pii/S089662731931044X
7. NIH BRAIN NeuroAI Workshop final program book (2024). https://braininitiative.nih.gov/sites/default/files/documents/2024%20NIH%20BRAIN%20NeuroAI%20Workshop%20Final%20Program%20Book_508c%201.pdf
8. NIH BRAIN Research Roadmap Innovation Domains (2025). https://www.braininitiative.nih.gov/sites/default/files/2025-11/BRAIN%20Research%20Roadmap%20Innovation%20Domains_508c.pdf

