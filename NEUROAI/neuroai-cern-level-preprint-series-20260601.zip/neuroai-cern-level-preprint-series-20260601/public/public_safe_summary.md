# Public-Safe Summary

This packet develops a four-paper NeuroAI preprint series at big-science rigor. The papers frame NeuroAI as an infrastructure-grade research program connecting neuroscience and artificial intelligence through shared benchmarks, predictive world-modeling theories, neural-data evaluation, and biologically plausible dynamical learning.

The packet is public-safe as a research framework. It does not claim clinical validation, regulatory approval, completed Medina implementation, legal protection, external notarization, or proven artificial general intelligence. All strong claims are bounded as strategic theses, hypotheses, protocol candidates, theorem candidates, or educational claims.
