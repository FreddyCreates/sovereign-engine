# Release Boundary

## Allowed Public Claims

- NeuroAI is a research field connecting neuroscience and artificial intelligence.
- Recent literature argues for coordinated NeuroAI infrastructure and embodied evaluation.
- Brain-Score and NeuralBench are examples of benchmark infrastructure for comparing models against neural, behavioral, or brain-recording data.
- Predictive coding and active inference are influential frameworks, but their empirical status and AI translation require careful comparison against alternatives.
- Recurrent, plastic, and dynamical learning systems are important research directions for NeuroAI.

## Blocked Claims

- Do not claim Medina has built or deployed a complete NeuroAI platform from this packet.
- Do not claim clinical validity or medical diagnostic performance.
- Do not claim regulatory approval.
- Do not claim that predictive coding, active inference, or any single framework is proven as a universal theory of brain function.
- Do not claim external notarization, legal filing, patent protection, or chain registration.
- Do not claim CERN endorsement or affiliation; “CERN-level” is used as a rigor metaphor only.

## Required Wording

Use “big-science rigor,” “CERN-scale analogy,” “research program,” “benchmark proposal,” “hypothesis,” and “architecture thesis.” Avoid “proven,” “deployed,” “clinically validated,” “notarized,” and “solved intelligence.”
