# Reproducibility Notes

## Source Method

The packet was created from a targeted literature survey and THESIS claim-boundary workflow on 2026-06-01. The source base emphasizes credible primary or platform sources: Nature Communications, arXiv, Brain-Score, PubMed-indexed review records, NIH BRAIN workshop/roadmap material, and recent Nature Communications work on predictive alignment.

## Reconstruction Steps

1. Use the README triage to identify packet class and release boundary.
2. Use the evidence matrix to recover source-to-claim mapping.
3. Read each manuscript as a distinct contribution rather than a single divided essay.
4. Check the claims matrix before promoting any sentence into abstract, press, grant, or submission language.
5. Recompute the hash manifest after any edits.

## Limitations

- No full systematic review was performed.
- No experiments, model training, or benchmark runs were executed.
- No external peer review has occurred.
- Citations are sufficient for draft grounding but should be expanded before formal submission.
