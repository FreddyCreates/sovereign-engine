# NeuroAI CERN-Level Preprint Series Packet

Packet ID: `NEUROAI-CERN-SERIES-20260601`  
Created: `2026-06-01T22:41:00Z`  
Authority state: `CLAIM_HARDENED / PUBLIC_SAFE_DRAFT`  
Release boundary: `public_safe_after_operator_review`

## Intake Triage

- Work object: `journal_packet / paper_series / public_claim`
- Task goal: `research_expansion + packet_build + claim_hardening`
- Claim class: primarily `C4 strategic thesis`, `C8 protocol candidate`, `C9 theorem candidate`, and `C10 public-safe educational claim`
- Proof posture: `supported_but_incomplete`; current citations support field framing and benchmark facts, not Medina-specific implementation
- Release boundary: `public_safe_draft`; no clinical, regulatory, deployment, or notarization claims
- Primary route: `publication packet build`

## Series Papers

1. **NeuroAI as Big Science** - argues for CERN-scale NeuroAI infrastructure.
2. **Predictive World Models for NeuroAI** - frames predictive coding and active inference as bounded, falsifiable architecture hypotheses.
3. **Brain-Aligned Benchmarks for NeuroAI** - defines typed benchmark claims and benchmark governance.
4. **Biologically Plausible Dynamics for NeuroAI** - argues for recurrent, plastic, embodied, and dynamical learning as a first-class research axis.

## Packet Contents

- `papers/` Markdown manuscripts
- `pdf/` rendered PDFs
- `matrices/claims_matrix.json`
- `matrices/evidence_matrix.json`
- `public/release_boundary.md`
- `public/public_safe_summary.md`
- `reproducibility.md`
- `manifests/lineage_record.json`
- `manifests/hash_manifest.json`
- `notary/notary_packet.json`

## Promotion Status

These are serious preprint-grade drafts, not final submitted papers. They should receive source review, domain review, and citation expansion before submission to arXiv, Zenodo, a workshop, or a journal venue.
