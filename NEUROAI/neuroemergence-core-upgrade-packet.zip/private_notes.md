# Private Notes

Authority state: INTERNAL_RESEARCH / IP_REVIEW_FIRST

These notes are intentionally not public-safe. They identify what should remain internal until Medina decides the correct IP, proof, and release route.

## Keep Internal

- Medina/Auro runtime positioning beyond high-level public framing.
- Any private canister architecture, runtime law, internal governance mechanism, or memory substrate detail not already approved for release.
- Military/political training framing from the Agent R&D report.
- Clinical or pharmacological framing that could be mistaken for medical validity.
- Raw mechanism details that could weaken future IP claims.

## Counsel/IP Review Candidates

- "Rotation" as a tempo-governance mechanism for persistent multi-agent cognition.
- Role-bearing canister organs for memory, verification, governance, and execution.
- Proof-bounded reporting pipeline that can issue weak-effect verdicts and block promotion claims.
- Neuroemergence Core as an embodied simulation testbed connected to persistent cognitive infrastructure.

## Blocked Public Language

- Proved consciousness.
- Validated clinical effect.
- Biological brain modified.
- Military/political readiness achieved.
- Deployed autonomous organism.
- Production-ready canister system.

## Safer Public Language

- Proposed architecture.
- Internal simulation telemetry.
- Brain-inspired embodied simulation.
- Preliminary benchmark contrast.
- Validity-aware controlled report.
- Requires reproduction and external review.
