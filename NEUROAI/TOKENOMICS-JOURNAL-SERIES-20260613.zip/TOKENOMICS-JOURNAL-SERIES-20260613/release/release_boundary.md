# Release Boundary

## Public-Safe

The PDFs in `papers_pdf/` and markdown files in `papers_md/` are public-safe research drafts after operator review. They use bounded language: proposed framework, candidate metric, benchmark pending.

## Controlled / Internal

The callable artifacts are intended for Medina/operator agent ingestion and controlled research workflows. They may be shared internally or with trusted reviewers. Public release requires a separate boundary pass.

## Sealed Reference

The copied source reference in `source/` preserves the protected Phantom source lineage. It should remain sealed unless the operator approves broader release.

## Blocked Claims

Do not claim:

- verified Tokenomics superiority
- production deployment
- patent filing or legal protection
- live chain notarization
- peer-reviewed acceptance

until external evidence or receipts are attached.
