#!/usr/bin/env python3
"""Small Tokenomics scoring utility.

Usage:
  python tokenomics_scorer.py --tokens 800 --dq 4 --act 4 --risk 3 --reuse 2 --learn 2 --accuracy 4 --waste 1
"""
import argparse, json

parser = argparse.ArgumentParser()
parser.add_argument('--tokens', type=float, required=True)
parser.add_argument('--dq', type=float, required=True)
parser.add_argument('--act', type=float, required=True)
parser.add_argument('--risk', type=float, required=True)
parser.add_argument('--reuse', type=float, required=True)
parser.add_argument('--learn', type=float, required=True)
parser.add_argument('--accuracy', type=float, required=True)
parser.add_argument('--waste', type=float, required=True)
args = parser.parse_args()
net = args.dq + args.act + args.risk + args.reuse + args.learn + args.accuracy - args.waste
crpt = net / args.tokens if args.tokens else 0
print(json.dumps({'net_score': net, 'tokens': args.tokens, 'crpt': crpt}, indent=2))
