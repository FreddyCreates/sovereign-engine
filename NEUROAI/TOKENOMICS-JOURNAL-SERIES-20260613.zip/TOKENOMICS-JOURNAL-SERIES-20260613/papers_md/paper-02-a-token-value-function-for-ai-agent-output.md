---
title: "A Token Value Function for AI Agent Output"
subtitle: "Scoring decision value, action usefulness, risk reduction, reuse, and waste"
author: "Medina Research / THESIS Alpha"
date: "2026-06-13"
geometry: margin=1in
fontsize: 11pt
---

# A Token Value Function for AI Agent Output

*Scoring decision value, action usefulness, risk reduction, reuse, and waste*

Paper ID: `PAPER-02`  
Series: Tokenomics Journal Series  
Status: Public-safe research draft / benchmark-pending


**Release and proof boundary.** This paper is a public-safe research draft derived from a protected THESIS Phantom packet. It presents Tokenomics as a proposed framework and benchmark program. It does not claim legal filing, live notarization, deployed runtime status, or verified performance superiority. Benchmark superiority claims require executed comparisons and attached results.


## Abstract

This paper defines a candidate Token Value Function for AI agent outputs. The function treats output tokens as units of cognitive expenditure whose value depends on the task. A token has positive value when it improves decision quality, enables action, reduces risk, compresses knowledge, or creates reusable memory. It has negative value when it repeats known context, increases ambiguity, adds filler, or consumes attention without improving the outcome.

The paper presents a public-safe formulation of the function, discusses scoring dimensions, and distinguishes metric design from empirical validation. The function is a proposed model, not a verified performance result.

## 1. Motivation

A token is usually priced by cost and counted by quantity. But users do not experience tokens as abstract units. They experience them as attention, time, clarity, uncertainty, and momentum. A system that spends 1,000 tokens and produces a correct invoice, a usable risk warning, or a reusable template has generated value. A system that spends 1,000 tokens on a polished but non-actionable essay has not.

The Token Value Function provides a way to ask what each part of an output contributed.

## 2. Candidate Function

The protected packet contains a more exact formula stack. The public-safe form can be stated as:

```text
Token Value = Decision Quality + Actionability + Risk Control + Reuse + Learning - Waste
```

This form is intentionally practical. It can be scored by humans, approximated by automated evaluators, and attached to benchmark tasks. It also creates a bridge between research language and runtime control: if token value can be estimated, an agent can decide what to include, what to compress, what to omit, and what to preserve.

## 3. Positive Value Components

Decision Quality captures whether the output improves the user's actual decision. It is not enough for the text to be relevant. It must clarify what should be done or what evidence matters.

Actionability captures whether the output can be used immediately. A plan, checklist, code snippet, workflow, revised document, or completed calculation usually scores higher than an explanation that leaves the user to assemble the next step.

Risk Control captures whether the output prevents errors. Risk can be financial, operational, scientific, legal, reputational, or epistemic. A token that names a missing assumption may be more valuable than a paragraph of confident advice.

Reuse captures whether the output creates future leverage. Examples include rules, schemas, templates, benchmarks, prompts, and memory records.

Learning captures whether the interaction improves the future system. This is especially important for agents that update workflows or remember operator preferences.

## 4. Negative Value: Waste

Waste is not only verbosity. It includes irrelevant structure, repeated background, decorative caveats, generic summaries, inflated claims, and hidden uncertainty. A response can be short and still wasteful if it fails to answer the task. It can be long and still efficient if each section contributes to action or risk reduction.

The waste term is important because it prevents the metric from rewarding length disguised as thoroughness.

## 5. Scoring Protocol

A minimal scoring protocol can use 0-5 values:

| Dimension | Score 0 | Score 5 |
| --- | --- | --- |
| Decision Quality | No decision improvement | Clearly improves the actual decision |
| Actionability | No usable next step | Immediate executable next step or artifact |
| Risk Control | Hides risk | Surfaces major failure modes and constraints |
| Reuse | One-off text only | Creates reusable rule, schema, or artifact |
| Learning | No future improvement | Improves future system behavior |
| Waste | No irrelevant output | High redundancy or filler |

The net score can then be divided by total tokens to estimate cognitive return per token.

## 6. Evaluation Risks

A Token Value Function can be misused. If scoring is too subjective, it may become rhetoric. If automated scoring is poorly designed, it may reward superficial clarity. If waste penalties are too aggressive, the system may omit necessary uncertainty. For this reason, early Tokenomics evaluation should include human review, task success checks, and explicit risk preservation tests.

## 7. Research Implications

The function turns qualitative output critique into measurable feedback. It can be used in agent training, prompt evaluation, benchmark design, memory consolidation, and runtime monitoring. It also creates a way to compare two outputs that are both correct but differ in actionability and cost.

## 8. Conclusion

The Token Value Function is a candidate measurement layer for AI output. Its purpose is not to punish length, but to reward useful cognitive work. The function becomes valuable when connected to benchmark tasks, runtime policies, and a disciplined claim boundary.



## References and Anchor Literature

- Shannon, C. E. (1948). A mathematical theory of communication. Bell System Technical Journal.
- Simon, H. A. (1955). A behavioral model of rational choice. Quarterly Journal of Economics.
- Goodhart, C. A. E. (1975). Problems of monetary management: the U.K. experience. Papers in Monetary Economics.
- Rissanen, J. (1978). Modeling by shortest data description. Automatica.
- Tversky, A., and Kahneman, D. (1979). Prospect theory: an analysis of decision under risk. Econometrica.
- Russell, S., and Norvig, P. (2021). Artificial Intelligence: A Modern Approach. Pearson.

These references are included as conceptual anchors. A venue-specific submission should expand and verify the bibliography against the target venue's citation standards.

