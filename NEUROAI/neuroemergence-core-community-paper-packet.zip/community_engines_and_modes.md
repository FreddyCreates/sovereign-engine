# Community Engines and Modes for Medina Research Papers

## Purpose

This document defines a new THESIS release layer for making Medina research papers more readable, more memorable, and more community-shareable without weakening proof discipline.

The goal is not hype.

The goal is proof-bounded virality: a paper should travel because the idea is sharp, the result is visible, the boundary is honest, and the community can do something with it.

## Core Engines

### 1. SIGNAL Engine

Find the one sentence that makes the community stop scrolling.

For Neuroemergence Core:

> Persistent agents should be evaluated by recovery, coherence, and bounded emergence, not just task output.

Output forms:

- one-line thesis;
- visual abstract headline;
- social post hook;
- talk-opening line;
- paper abstract lead.

### 2. PROOF-PULSE Engine

Attach the strongest evidence immediately after the hook.

For Neuroemergence Core:

- 60-run threat-memory-navigation dataset;
- baseline task success: 0.0000;
- brain-powered task success: 0.9881;
- coherence score: 0.1875 to 1.0000;
- self-state coherence: 0.3262 to 0.7460;
- cost: latency rises from 4.5255 ms to 16.1677 ms.

Rule:

No hook ships without a proof pulse.

### 3. BOUNDARY Engine

Make the paper harder to attack by saying what it does not prove.

Blocked claims:

- not biological consciousness;
- not clinical pharmacology;
- not in vivo brain effect;
- not general intelligence proof;
- not military readiness;
- not full backend verification;
- not legal or chain finality.

Rule:

Every viral claim needs a visible boundary.

### 4. STORY Engine

Turn the paper from a report into a journey.

Narrative sequence:

1. AI still starts over.
2. Persistent agents need internal state.
3. Emergence without governance is noise.
4. Neuroemergence Core tests governed emergence.
5. Brain-powered control separates from baseline.
6. The system also reports weak effects and saturation.
7. The community challenge is reproduction and ablation.

### 5. DEMO-BRIDGE Engine

Connect the paper to the deployed surface without overclaiming internals.

Safe language:

> Neuroemergence Core has a deployed web surface. This paper grounds technical claims in the uploaded reports and simulation dataset, while treating backend/runtime internals as requiring separate verification.

### 6. CHALLENGE Engine

Convert readers into participants.

Community challenge:

> Reproduce the threat-memory-navigation scenario, ablate the brain-powered mechanisms, and test whether governed rotation is the variable that drives recovery and coherence.

Outputs:

- GitHub issue prompt;
- benchmark challenge card;
- discussion-thread prompt;
- call for replication.

### 7. VISUAL-SIGNAL Engine

Turn dense research into shareable visual surfaces.

Required visuals:

- architecture diagram: organs, rotation, proof boundary;
- result card: baseline vs brain-powered metrics;
- limitation card: what this does not prove;
- roadmap card: reproduce, ablate, notarize, publish.

### 8. RELEASE-GATE Engine

Decide what can safely leave Medina.

Release classes:

- internal research paper;
- public-safe summary;
- community thread;
- visual abstract;
- benchmark challenge;
- IP-review packet;
- hash/notary packet.

Rule:

No community release without a boundary card and hash manifest.

## Operating Modes

### Mode 1 - Paper Mode

Audience: researchers, builders, reviewers.

Output:

- full manuscript;
- methods;
- results;
- limitations;
- references;
- claim boundary.

### Mode 2 - Community Thread Mode

Audience: AI builders and technical community.

Output:

1. Hook.
2. Problem.
3. Result.
4. Why it matters.
5. What it does not prove.
6. Deployment link.
7. Challenge.

### Mode 3 - Benchmark Card Mode

Audience: people who want numbers fast.

Output:

- one table;
- one sentence interpretation;
- one cost note;
- one replication ask.

### Mode 4 - Visual Abstract Mode

Audience: broad technical readership.

Output:

- single-page diagram;
- 4-panel flow: state -> rotation -> result -> boundary.

### Mode 5 - Critic-Proof Mode

Audience: skeptical reviewers.

Output:

- strongest objections;
- blocked claims;
- missing evidence;
- next experiment.

### Mode 6 - Builder Challenge Mode

Audience: open-source / research community.

Output:

- scenario definition;
- metric list;
- baseline result;
- ablation targets;
- leaderboard rules.

### Mode 7 - Deployment Story Mode

Audience: people who want to see it live.

Output:

- deployed surface link;
- what the deployment shows;
- what remains unverified;
- how deployment evidence should be captured next.

### Mode 8 - Notary Drop Mode

Audience: proof, provenance, archive, and IP stakeholders.

Output:

- hash manifest;
- Merkle root;
- packet file map;
- notarization target;
- operator approval state.

## Viral-Worthy Release Formula

Use this structure for every community-facing Medina research drop:

1. **Hook:** one sentence that names the shift.
2. **Signal:** one result that proves there is something real.
3. **Boundary:** one sentence that blocks overclaiming.
4. **Diagram:** one visual that makes the mechanism obvious.
5. **Challenge:** one action the community can take.
6. **Receipts:** one packet link, hash, or reproducibility note.

Formula:

`viral_worthy = hook + proof + boundary + visual + challenge + receipts`

If any part is missing, the release is not ready.

## Neuroemergence Core Community Hook Set

- AI agents should not only complete tasks. They should recover, regulate, and know when their evidence is weak.
- Neuroemergence Core turns "emergence" from a vibe into a measured, bounded runtime signal.
- The result is not "AI became conscious." The result is better: governed, brain-inspired control produced measurable coherence under constraint.
- Baseline failed the task. Brain-powered control nearly always solved it. The cost was latency. That is a real research shape.
- The most credible AI systems will not be the ones that claim the most. They will be the ones that know exactly what they can prove.

## Next Build Targets

- One-page visual abstract.
- Community thread.
- Benchmark challenge README.
- Public-safe landing summary.
- Reproducibility packet.
- Hash/notary packet.
